import torch
import numpy as np
import pandas as pd
import kitsune
from datetime import datetime

# Mapping for protocol conversion
PROTO_MAP = {"TCP": 6, "UDP": 17, "ICMP": 1}

def parse_timestamp(ts):
    try:
        return datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S.%f%z")
    except Exception:
        return None

def extract_base_features_from_raw(raw_input):
    """
    Extract 8 base features from a raw Suricata event (assumed to be a dict).
    Expected base features:
      [src_port, dest_port, pkts_toserver, pkts_toclient, bytes_toserver, bytes_toclient, duration, proto]
    """
    if raw_input.get("event_type") != "flow":
        return None

    flow = raw_input.get("flow", {})
    try:
        src_port = float(raw_input.get("src_port", 0))
        dest_port = float(raw_input.get("dest_port", 0))
        pkts_toserver = float(flow.get("pkts_toserver", 0))
        pkts_toclient = float(flow.get("pkts_toclient", 0))
        bytes_toserver = float(flow.get("bytes_toserver", 0))
        bytes_toclient = float(flow.get("bytes_toclient", 0))
    except Exception:
        return None

    start_ts = parse_timestamp(flow.get("start", ""))
    end_ts = parse_timestamp(flow.get("end", ""))
    duration = (end_ts - start_ts).total_seconds() if start_ts and end_ts else 0.0
    proto_str = raw_input.get("proto", "").upper()
    proto = float(PROTO_MAP.get(proto_str, 0))

    return [src_port, dest_port, pkts_toserver, pkts_toclient,
            bytes_toserver, bytes_toclient, duration, proto]

def compute_derived_features(bases):
    """
    Given 8 base features, compute a 115-dimensional feature vector.
    This includes:
      - 8 base features
      - 8 squares (each base feature squared)
      - 28 unordered differences (for each unique pair)
      - 56 ordered ratios (for each pair, if denominator nonzero)
      - 5 aggregate statistics (sum, mean, std, max, min)
      - 2 extra ratios (pkts_toserver/total_packets and bytes_toserver/total_bytes)
      - 8 additional features:
            1. Ratio of pkts_toserver to pkts_toclient
            2. Ratio of bytes_toserver to bytes_toclient
            3. Mean port (average of src and dest ports)
            4. Absolute difference between src and dest ports
            5. Bytes per packet for server side
            6. Bytes per packet for client side
            7. Total packets (pkts_toserver + pkts_toclient)
            8. Total bytes (bytes_toserver + bytes_toclient)
    Total = 8 + 8 + 28 + 56 + 5 + 2 + 8 = 115 features.
    """
    derived = []
    # 1. Base features (8)
    derived.extend(bases)
    # 2. Squares (8)
    derived.extend([x**2 for x in bases])
    # 3. Unordered differences (28)
    for i in range(len(bases)):
        for j in range(i+1, len(bases)):
            derived.append(bases[i] - bases[j])
    # 4. Ordered ratios (56)
    for i in range(len(bases)):
        for j in range(len(bases)):
            if i != j:
                denominator = bases[j]
                derived.append(bases[i] / denominator if denominator != 0 else 0)
    # 5. Aggregate statistics (5)
    base_arr = np.array(bases)
    derived.append(np.sum(base_arr))       # sum
    derived.append(np.mean(base_arr))        # mean
    derived.append(np.std(base_arr))         # std
    derived.append(np.max(base_arr))         # max
    derived.append(np.min(base_arr))         # min
    # 6. Two extra ratios (2)
    total_pkts = bases[2] + bases[3]
    derived.append(bases[2] / total_pkts if total_pkts != 0 else 0)
    total_bytes = bases[4] + bases[5]
    derived.append(bases[4] / total_bytes if total_bytes != 0 else 0)
    # 7. Additional 8 features:
    ratio_pkts = bases[2] / bases[3] if bases[3] != 0 else 0
    ratio_bytes = bases[4] / bases[5] if bases[5] != 0 else 0
    mean_port = (bases[0] + bases[1]) / 2
    abs_port_diff = abs(bases[0] - bases[1])
    bpp_server = bases[4] / bases[2] if bases[2] != 0 else 0
    bpp_client = bases[5] / bases[3] if bases[3] != 0 else 0
    derived.extend([ratio_pkts, ratio_bytes, mean_port, abs_port_diff,
                    bpp_server, bpp_client, total_pkts, total_bytes])
    return derived

def normalize_vector(vector):
    """
    Normalize the vector using min-max normalization to [0, 1].
    For consistency, you might use training statistics.
    """
    arr = np.array(vector)
    normalized = (arr - arr.min()) / (arr.max() - arr.min() + 1e-8)
    return normalized.tolist()

def load_model(checkpoint_path="kitsune/models/kitsune.pt"):
    """
    Load and return the pre-trained Kitsune model.
    """
    model = kitsune.Kitsune.from_pretrained(checkpoint_path)
    model.eval()
    return model

def compute_anomaly_score(model, processed_vector):
    """
    Given a loaded model and a processed, normalized feature vector (115-dim),
    compute and return a single anomaly score (float) by combining model outputs.
    """
    input_tensor = torch.tensor(processed_vector).unsqueeze(0)
    with torch.inference_mode():
        output = model(input_tensor)
    if isinstance(output, dict):
        head_loss = output.get("head_loss")
        tails_losses = output.get("tails_losses")
        # Example: combine head loss and mean of tail losses
        if head_loss is not None and tails_losses is not None:
            score = head_loss.item() + tails_losses.mean().item()
        else:
            score = 0.0
    else:
        score = output.item() if hasattr(output, "item") else float(output)
    return score

# The module exposes these functions for external use.
__all__ = [
    "parse_timestamp",
    "extract_base_features_from_raw",
    "compute_derived_features",
    "normalize_vector",
    "load_model",
    "compute_anomaly_score"
]
