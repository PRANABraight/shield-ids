# Building Suricata

Instead of including Suricata binaries in this repository, please follow these instructions to build it from source:

## Prerequisites

```bash
# Install Suricata dependencies
sudo apt update
sudo apt install -y build-essential libpcre3-dev libpcre3 libpcap-dev libnet1-dev \
  libyaml-0-2 libyaml-dev pkg-config zlib1g zlib1g-dev libcap-ng-dev libcap-ng0 \
  libmagic-dev libnss3-dev libgeoip-dev liblua5.1-0-dev libhtp-dev libjansson-dev \
  libjansson4 libpython2.7-dev rustc cargo
```

## Download and Build

```bash
# Download Suricata source (version 7.0.9)
wget https://www.openinfosecfoundation.org/download/suricata-7.0.9.tar.gz
tar -xvzf suricata-7.0.9.tar.gz
cd suricata-7.0.9

# Configure and build Suricata
./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var \
  --enable-nfqueue --enable-lua --enable-geoip --enable-rust
make -j $(nproc)

# Install Suricata (optional, requires root)
sudo make install
sudo make install-conf

# Setup Suricata rules (optional)
sudo suricata-update
```

## Verification

To verify Suricata is properly installed:

```bash
suricata --version
```

You should see output showing Suricata version 7.0.9.
