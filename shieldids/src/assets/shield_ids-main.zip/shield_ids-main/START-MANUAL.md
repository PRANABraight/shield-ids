# Manual Startup Guide for SHIELD IDS

This guide walks through the steps to manually start each component of the SHIELD IDS system.

## Prerequisites

Make sure you have:
- Node.js installed
- Redis server installed and running
- All dependencies installed in both server and client directories

## Step 1: Stop Any Existing Processes

```bash
# Kill any server or client processes
pkill -f "node.*server.js"
pkill -f "react-scripts start"
pkill -f "node.*eve-log-generator"
```

## Step 2: Start Redis (if not already running)

```bash
# Check if Redis is running
redis-cli ping

# If not running, start it
sudo systemctl start redis
```

## Step 3: Generate Test Logs (for testing without Suricata)

```bash
# Create a test log file
cd ~/shield_ids
node web_interface/server/scripts/eve-log-generator.js ./test-eve.json 1000 &
```

## Step 4: Start the Server (in a new terminal)

```bash
cd ~/shield_ids/web_interface/server

# Using the test log file
SURICATA_EVE_LOG=~/shield_ids/test-eve.json PORT=5050 node server.js
```

## Step 5: Start the Client (in a new terminal)

```bash
cd ~/shield_ids/web_interface/client

# Set the API URL environment variable
export REACT_APP_API_URL=http://localhost:5050

# Start the development server
npm start
```

## Step 6: Verify Data Flow

Open your browser to http://localhost:3000

## Troubleshooting

### 1. Socket.IO Connection Issues

If you see Socket.IO connection errors in the browser console:

```bash
# Edit the api.js file to use both websocket and polling transports
cd ~/shield_ids/web_interface/client/src
nano api.js

# Add/modify this code:
export const SOCKET_OPTIONS = {
  transports: ['websocket', 'polling'],
  reconnectionAttempts: 5,
  reconnectionDelay: 1000,
  timeout: 10000
};
```

### 2. Port Already in Use

```bash
# Find what's using the port
lsof -i :5050
lsof -i :3000

# Kill the processes
kill -9 <PID>
```

### 3. Check the Server API

```bash
# Test if the server is responding
curl http://localhost:5050/api/anomalyScores
curl http://localhost:5050/api/alerts
```

### 4. Check Redis Connection

```bash
# Make sure Redis is accessible
redis-cli ping
```

## Graceful Shutdown

To stop everything:

```bash
# Kill the client
pkill -f "react-scripts start"

# Kill the server
pkill -f "node.*server.js"

# Kill the log generator
pkill -f "node.*eve-log-generator"
``` 