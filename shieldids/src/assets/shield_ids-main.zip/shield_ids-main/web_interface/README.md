# SHIELD IDS - Real-Time Network Intrusion Detection System

SHIELD IDS is a comprehensive web-based Intrusion Detection System dashboard that visualizes real-time network security data from Suricata logs. This dashboard provides real-time anomaly detection, alert visualization, and network traffic monitoring capabilities.

## Features

- **Real-Time Anomaly Detection**: Monitor anomaly scores derived from network traffic analysis in real-time
- **Live Attack Feed**: See incoming security alerts as they happen with severity indicators
- **Network Traffic Visualization**: Track network traffic patterns in real-time
- **Comprehensive Alert Dashboard**: Filter, search, and analyze security alerts
- **Dark Theme Interface**: Modern, security-focused dark UI optimized for monitoring environments

## System Architecture

The system consists of two main components:

1. **Backend Server**:
   - Node.js Express server
   - Real-time log tailing of Suricata's EVE JSON logs
   - Socket.IO for pushing real-time updates to clients
   - Redis for caching and data persistence

2. **Frontend Dashboard**:
   - React-based UI with Material UI components
   - Real-time updates via Socket.IO
   - Performance-optimized visualizations with Recharts
   - Responsive design for various screen sizes

## Getting Started

### Prerequisites

- Node.js (v14.x or later)
- Redis server
- Suricata IDS with EVE JSON logging enabled

### Configuration

The following environment variables can be set to configure the application:

- `PORT` - Backend server port (default: 5050)
- `REDIS_URL` - Redis connection string (default: redis://localhost:6379)
- `SURICATA_EVE_LOG` - Path to Suricata's eve.json log file (default: /var/log/suricata/eve.json)

### Installation

1. Clone the repository
2. Install dependencies:

```bash
# Install backend dependencies
cd server
npm install

# Install frontend dependencies
cd ../client
npm install
```

### Running the Application

#### Production Mode

```bash
# Start the backend server
cd server
npm start

# Build and serve the frontend
cd ../client
npm run build
npx serve -s build
```

#### Development Mode

```bash
# Start the backend server
cd server
npm run dev

# Run the frontend development server
cd ../client
npm start
```

#### Testing with Simulated Logs

For testing without a running Suricata instance, you can use the included log generator:

```bash
# Generate test logs
cd server/scripts
node eve-log-generator.js /path/to/test-eve.json 2000
```

Then set the `SURICATA_EVE_LOG` environment variable to point to your generated log file:

```bash
SURICATA_EVE_LOG=/path/to/test-eve.json npm run dev
```

## Real-Time Components

### Log Tailing System

The backend implements a robust log tailing system that:

- Watches the Suricata EVE JSON log file for changes
- Handles log rotation events
- Provides efficient parsing of JSON log entries
- Includes retry logic for error recovery
- Emits events for real-time client updates

### RealTimeScore Component

The `RealTimeScores` component displays anomaly scores detected in the network:

- Connects to the backend via Socket.IO for real-time updates
- Visualizes anomaly scores in a time-series chart
- Shows current threat level with color-coded indicators
- Includes performance optimizations for smooth updates
- Provides error handling and connection status indicators

### Performance Optimizations

The system includes several performance optimizations:

- Socket.IO configured to use WebSocket transport for efficiency
- Debounced updates to prevent UI re-renders during high-frequency events
- Memoized components and charting elements to reduce rendering overhead
- Data point limiting to maintain performance with large datasets
- Error boundaries to prevent component crashes

## API Endpoints

### Socket.IO Events

- `update` - Real-time anomaly score updates
- `alertUpdate` - New security alert notifications
- `trafficUpdate` - Network traffic volume updates
- `alertDistributionUpdate` - Alert category distribution updates
- `correlationUpdate` - Correlation between traffic and anomaly scores

### REST API

- `GET /api/anomalyScores` - Fetch historical anomaly scores
- `GET /api/alerts` - Fetch security alerts
- `GET /api/trafficVolume` - Get current network traffic volume
- `GET /api/alertDistribution` - Get alert category distribution
- `GET /api/stats` - Get statistical summaries
- `GET /api/alertHeatmap` - Get temporal distribution of alerts
- `GET /api/correlation` - Get correlation data between metrics
- `GET /api/health` - System health status

## Changelog

### Backend Enhancements

- **Added robust log tailer**: Implemented a reliable system for tailing and processing Suricata's eve.json logs in real-time
- **Improved Socket.IO setup**: Enhanced connection handling with better error recovery and event management
- **Added anomaly detection processing**: Improved parsing and handling of anomaly score data from logs
- **Added health monitoring endpoint**: Added system status monitoring for improved reliability
- **Implemented graceful shutdown**: Added proper cleanup of resources during server shutdown
- **Enhanced error handling**: Added robust error handling throughout the backend

### Frontend Enhancements

- **Enhanced RealTimeScores component**: 
  - Added real-time visualization of anomaly scores
  - Implemented threat level indicators with color coding
  - Added responsive layout with current score display
  - Included connection status indicators
  
- **Improved AnomalyHistoryChart**:
  - Added threshold reference lines for warning and critical levels
  - Enhanced tooltips with detailed information
  - Improved visual design with gradients and better colors
  - Added optimizations for smooth real-time updates

- **General improvements**:
  - Added performance monitoring and optimization utilities
  - Implemented memoization for performance-critical components
  - Added error boundaries for graceful error handling
  - Enhanced visual consistency with the dark theme 