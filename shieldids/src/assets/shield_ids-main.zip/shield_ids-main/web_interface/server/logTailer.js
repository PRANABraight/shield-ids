const fs = require('fs');
const readline = require('readline');
const EventEmitter = require('events');
const path = require('path');

class LogTailer extends EventEmitter {
  constructor(options = {}) {
    super();
    
    // Default options
    this.options = {
      logPath: process.env.SURICATA_EVE_LOG || '/var/log/suricata/eve.json',
      pollInterval: 1000,
      ...options
    };
    
    this.lastSize = 0;
    this.watching = false;
    this.watcher = null;
    this.retryCount = 0;
    this.maxRetries = 10;
    this.retryInterval = 5000;
    this.isFirstRun = true;
  }

  /**
   * Start watching the log file for changes
   */
  start() {
    console.log(`Starting log tailer for: ${this.options.logPath}`);
    
    try {
      // Ensure the log file exists
      if (!fs.existsSync(this.options.logPath)) {
        const error = new Error(`Log file not found: ${this.options.logPath}`);
        this.emit('error', error);
        this.scheduleRetry();
        return;
      }

      this.lastSize = fs.statSync(this.options.logPath).size;
      
      // If this is the first run, we only read the last few lines
      // to avoid overwhelming the system with old logs
      if (this.isFirstRun) {
        this.readLastLines(10);
        this.isFirstRun = false;
      }
      
      // Set up file watcher
      this.watcher = fs.watch(this.options.logPath, (eventType) => {
        if (eventType === 'change') {
          this.checkForChanges();
        }
      });
      
      // Also poll periodically in case the watcher misses something
      this.intervalId = setInterval(() => {
        this.checkForChanges();
      }, this.options.pollInterval);
      
      this.watching = true;
      this.retryCount = 0;
      this.emit('start', { path: this.options.logPath });
      
    } catch (error) {
      this.emit('error', error);
      this.scheduleRetry();
    }
  }

  /**
   * Stop watching the log file
   */
  stop() {
    if (this.watcher) {
      this.watcher.close();
      this.watcher = null;
    }
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    
    this.watching = false;
    this.emit('stop');
  }

  /**
   * Check for changes in the log file
   */
  checkForChanges() {
    try {
      const stats = fs.statSync(this.options.logPath);
      const currentSize = stats.size;
      
      // If file size decreased, the log was rotated
      if (currentSize < this.lastSize) {
        this.emit('rotate', { 
          oldSize: this.lastSize,
          newSize: currentSize
        });
        this.lastSize = 0;
        this.readNewLines(0);
      } 
      // If file size increased, read the new lines
      else if (currentSize > this.lastSize) {
        this.readNewLines(this.lastSize);
        this.lastSize = currentSize;
      }
    } catch (error) {
      this.emit('error', error);
      this.scheduleRetry();
    }
  }

  /**
   * Read new lines from the log file
   * @param {number} startPosition Position to start reading from
   */
  readNewLines(startPosition) {
    try {
      const stream = fs.createReadStream(this.options.logPath, {
        start: startPosition,
        encoding: 'utf8'
      });
      
      let buffer = '';
      
      stream.on('data', (chunk) => {
        buffer += chunk;
        
        // Process complete lines
        const lines = buffer.split('\n');
        buffer = lines.pop(); // Keep the last incomplete line in the buffer
        
        for (const line of lines) {
          if (line.trim()) {
            try {
              const logEntry = JSON.parse(line);
              this.emit('line', logEntry);
            } catch (parseError) {
              this.emit('parseError', { line, error: parseError });
            }
          }
        }
      });
      
      stream.on('end', () => {
        // Process any remaining data
        if (buffer.trim()) {
          try {
            const logEntry = JSON.parse(buffer);
            this.emit('line', logEntry);
          } catch (parseError) {
            this.emit('parseError', { line: buffer, error: parseError });
          }
        }
      });
      
      stream.on('error', (error) => {
        this.emit('error', error);
      });
      
    } catch (error) {
      this.emit('error', error);
    }
  }

  /**
   * Read the last N lines from the log file
   * @param {number} numLines Number of lines to read
   */
  readLastLines(numLines) {
    try {
      const stats = fs.statSync(this.options.logPath);
      const fileSize = stats.size;
      
      // For small files, just read the entire file
      if (fileSize < 10000) {
        this.readNewLines(0);
        return;
      }
      
      // For larger files, try to read approximately the last N lines
      // This is an approximation as we don't know line lengths in advance
      const averageLineSize = 500; // Estimated average line size in bytes
      const startPosition = Math.max(0, fileSize - (numLines * averageLineSize));
      
      const stream = fs.createReadStream(this.options.logPath, {
        start: startPosition,
        encoding: 'utf8'
      });
      
      let buffer = '';
      
      stream.on('data', (chunk) => {
        buffer += chunk;
      });
      
      stream.on('end', () => {
        // Split the buffer into lines
        const lines = buffer.split('\n');
        
        // Skip the first line as it might be incomplete
        const linesToProcess = lines.slice(1).slice(-numLines);
        
        for (const line of linesToProcess) {
          if (line.trim()) {
            try {
              const logEntry = JSON.parse(line);
              this.emit('line', logEntry);
            } catch (parseError) {
              this.emit('parseError', { line, error: parseError });
            }
          }
        }
      });
      
      stream.on('error', (error) => {
        this.emit('error', error);
      });
      
    } catch (error) {
      this.emit('error', error);
    }
  }

  /**
   * Schedule a retry after an error
   */
  scheduleRetry() {
    if (this.retryCount < this.maxRetries) {
      this.retryCount++;
      
      console.log(`Retrying log tailer in ${this.retryInterval}ms (Attempt ${this.retryCount}/${this.maxRetries})`);
      
      setTimeout(() => {
        this.start();
      }, this.retryInterval);
    } else {
      console.error(`Failed to start log tailer after ${this.maxRetries} attempts.`);
      this.emit('fatalError', new Error('Max retry attempts reached'));
    }
  }
}

module.exports = LogTailer; 