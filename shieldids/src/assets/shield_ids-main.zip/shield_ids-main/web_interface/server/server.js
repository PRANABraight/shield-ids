const express = require("express");
const cors = require("cors");
const http = require("http");
const socketIo = require("socket.io");
const si = require("systeminformation");
const redis = require("redis");
const { createAdapter } = require("socket.io-redis");
const LogTailer = require("./logTailer");
const path = require("path");
const os = require("os");

const app = express();
const port = process.env.PORT || 5050;

app.use(express.json());
app.use(cors());

// Configuration for log tailer
const DEFAULT_EVE_LOG_PATH = "/var/log/suricata/eve.json";
const logPath = process.env.SURICATA_EVE_LOG || DEFAULT_EVE_LOG_PATH;

// Create a Redis client
const redisUrl = process.env.REDIS_URL || "redis://localhost:6379";
const redisClient = redis.createClient({ url: redisUrl });
redisClient.connect().catch(console.error);

// Create HTTP server
const server = http.createServer(app);

// Initialize Socket.IO with the server
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Set up Redis adapter for Socket.IO if needed
if (redisClient.isReady) {
  const subClient = redisClient.duplicate();
  io.adapter(createAdapter({ pubClient: redisClient, subClient }));
}
// ------------------------------
// Helper functions for Redis Data Storage
// ------------------------------

async function storeAnomalyScore(entry) {
  try {
    await redisClient.lPush("anomalyScores", JSON.stringify(entry));
    await redisClient.lTrim("anomalyScores", 0, 99); // Keep last 100 entries
  } catch (error) {
    console.error("Error storing anomaly score in Redis:", error);
  }
}

async function getAnomalyScoresFromRedis() {
  try {
    const scores = await redisClient.lRange("anomalyScores", 0, -1);
    return scores.map(JSON.parse).reverse(); // Reverse to get chronological order
  } catch (error) {
    console.error("Error fetching anomaly scores from Redis:", error);
    return [];
  }
}

async function storeAlert(alert) {
  try {
    await redisClient.lPush("alerts", JSON.stringify(alert));
    await redisClient.lTrim("alerts", 0, 99); // Keep last 100 alerts
  } catch (error) {
    console.error("Error storing alert in Redis:", error);
  }
}

async function getAlertsFromRedis() {
  try {
    const alertList = await redisClient.lRange("alerts", 0, -1);
    return alertList.map(JSON.parse).reverse();
  } catch (error) {
    console.error("Error fetching alerts from Redis:", error);
    return [];
  }
}
async function getTrafficData() {
  try {
    const netStats = await si.networkStats();
    const stats = netStats[0];
    return [{
      time: new Date().toLocaleTimeString(),
      bytesPerSec: stats.rx_sec + stats.tx_sec,
    }];
  } catch (error) {
    console.error("Error fetching traffic data:", error);
    return [];
  }
}

async function getAlertDistribution() {
  const alertList = await getAlertsFromRedis();
  const distribution = {};
  alertList.forEach((alert) => {
    const type = alert.msg || "Unknown";
    distribution[type] = (distribution[type] || 0) + 1;
  });
  return Object.keys(distribution).map(type => ({ type, count: distribution[type] }));
}

async function getCorrelationData() {
  try {
    const netStats = await si.networkStats();
    const stats = netStats[0];
    const currentTraffic = stats.rx_sec + stats.tx_sec;
    const anomalyData = await getAnomalyScoresFromRedis();
    const latestAnomaly = anomalyData[anomalyData.length - 1] || { score: 0, time: new Date().toLocaleTimeString() };
    return [{
      time: new Date().toLocaleTimeString(),
      trafficVolume: currentTraffic,
      anomalyScore: latestAnomaly.score
    }];
  } catch (error) {
    console.error("Error fetching correlation data:", error);
    return [];
  }
}
// ------------------------------
// Suricata Log Processing Functions
// ------------------------------

/**
 * Process a line from the Suricata EVE log file
 */
function processLogEntry(entry) {
  // Check if this is an alert entry
  if (entry.event_type === 'alert') {
    processAlertEntry(entry);
  }
  
  // Check if this is an anomaly score entry (from Kitsune)
  if (entry.event_type === 'anomaly' || 
      (entry.anomaly !== undefined && entry.score !== undefined)) {
    processAnomalyEntry(entry);
  }
  
  // Emit raw log entries for debugging purposes
  io.emit('logEntry', {
    timestamp: entry.timestamp,
    event_type: entry.event_type
  });
}

/**
 * Process an alert entry from Suricata
 */
async function processAlertEntry(entry) {
  try {
    // Format the alert data for our frontend
    const alertData = {
      timestamp: entry.timestamp,
      time: new Date(entry.timestamp).toLocaleTimeString(),
      src_ip: entry.src_ip,
      dest_ip: entry.dest_ip,
      proto: entry.proto,
      msg: entry.alert?.signature || 'Unknown Alert',
      category: entry.alert?.category || '',
      severity: entry.alert?.severity || 0,
      signature_id: entry.alert?.signature_id,
      action: entry.alert?.action
    };
    
    // Store in Redis and broadcast to clients
    await storeAlert(alertData);
    io.emit('alertUpdate', alertData);
    
    console.log(`Processed alert: ${alertData.msg}`);
  } catch (error) {
    console.error('Error processing alert entry:', error);
  }
}

/**
 * Process an anomaly score entry
 */
async function processAnomalyEntry(entry) {
  try {
    // Extract the anomaly score
    const score = entry.score || entry.anomaly?.score || 0;
    
    // Format the anomaly data
    const anomalyData = {
      score: parseFloat(score),
      time: entry.timestamp ? new Date(entry.timestamp).toLocaleTimeString() : new Date().toLocaleTimeString(),
      timestamp: entry.timestamp || new Date().toISOString()
    };
    
    // Store in Redis and broadcast to clients
    await storeAnomalyScore(anomalyData);
    io.emit('update', [anomalyData]);
    
    console.log(`Processed anomaly score: ${anomalyData.score}`);
  } catch (error) {
    console.error('Error processing anomaly entry:', error);
  }
}

// ------------------------------
// Initialize Log Tailer
// ------------------------------

// Create and start the log tailer
const logTailer = new LogTailer({
  logPath: logPath,
  pollInterval: 1000
});

// Handle log entries
logTailer.on('line', (entry) => {
  processLogEntry(entry);
});

// Handle log tailer errors
logTailer.on('error', (error) => {
  console.error('Log tailer error:', error);
});

// Handle log rotation
logTailer.on('rotate', ({ oldSize, newSize }) => {
  console.log(`Log rotation detected: ${oldSize} -> ${newSize} bytes`);
});

// Handle log tailer start
logTailer.on('start', ({ path }) => {
  console.log(`Log tailer started for: ${path}`);
});

// Handle fatal errors
logTailer.on('fatalError', (error) => {
  console.error('Fatal error in log tailer:', error);
  // Consider graceful shutdown or restart in production
});

// Start the log tailer
logTailer.start();

// ------------------------------
// API Endpoints
// ------------------------------

// Endpoint to receive anomaly scores from the Python inference script
app.post("/api/anomalyRealTime", async (req, res) => {
  const { anomalyScore } = req.body;
  if (anomalyScore !== undefined) {
    const entry = { 
      score: anomalyScore, 
      time: new Date().toLocaleTimeString(),
      timestamp: new Date().toISOString()
    };
    await storeAnomalyScore(entry);
    console.log("Received anomaly score via API:", entry);
    io.emit("update", [entry]);
  }
  res.sendStatus(200);
});

// Endpoint to fetch all anomaly scores
app.get("/api/anomalyScores", async (req, res) => {
  const scores = await getAnomalyScoresFromRedis();
  res.json(scores);
});

// Endpoint to receive signature-based alerts
app.post("/api/alerts", async (req, res) => {
  const alert = req.body;
  if (alert) {
    // Ensure a proper timestamp is added if not present
    if (!alert.timestamp && !alert.time) {
      alert.timestamp = new Date().toISOString();
      alert.time = new Date().toLocaleTimeString();
    }
    await storeAlert(alert);
    console.log("Received alert via API:", alert);
    io.emit("alertUpdate", alert);
  }
  res.sendStatus(200);
});

// Endpoint to fetch all alerts
app.get("/api/alerts", async (req, res) => {
  const alertList = await getAlertsFromRedis();
  res.json(alertList);
});

// Real-time traffic volume endpoint
app.get("/api/trafficVolume", async (req, res) => {
  try {
    const netStats = await si.networkStats();
    const stats = netStats[0];
    const trafficData = [{
      time: new Date().toLocaleTimeString(),
      bytesPerSec: stats.rx_sec + stats.tx_sec,
    }];
    res.json(trafficData);
    io.emit("trafficUpdate", trafficData);
  } catch (error) {
    console.error("Error fetching traffic volume:", error);
    res.status(500).json({ error: "Failed to fetch traffic volume" });
  }
});

// Alert distribution endpoint
app.get("/api/alertDistribution", async (req, res) => {
  const alertList = await getAlertsFromRedis();
  const distribution = {};
  alertList.forEach((alert) => {
    const type = alert.msg || "Unknown";
    distribution[type] = (distribution[type] || 0) + 1;
  });
  const result = Object.keys(distribution).map(type => ({ type, count: distribution[type] }));
  res.json(result);
  io.emit("alertDistributionUpdate", result);
});

// Statistical summaries endpoint
app.get("/api/stats", async (req, res) => {
  const alertsData = await getAlertsFromRedis();
  const anomalyData = await getAnomalyScoresFromRedis();
  const totalAlerts = alertsData.length;
  const avgAnomalyScore = anomalyData.length > 0
    ? anomalyData.reduce((sum, entry) => sum + entry.score, 0) / anomalyData.length
    : 0;
  
  const result = { totalAlerts, avgAnomalyScore };
  res.json(result);
  io.emit("statsUpdate", result);
});

// Correlation data endpoint
app.get("/api/correlation", async (req, res) => {
  try {
      const netStats = await si.networkStats();
      const stats = netStats[0];
      const currentTraffic = stats.rx_sec + stats.tx_sec;
      const anomalyData = await getAnomalyScoresFromRedis();
      const latestAnomaly = anomalyData[anomalyData.length - 1] || { score: 0, time: new Date().toLocaleTimeString() };
      const correlationData = [{
          time: new Date().toLocaleTimeString(),
          trafficVolume: currentTraffic,
          anomalyScore: latestAnomaly.score
      }];
      res.json(correlationData);
      io.emit("correlationUpdate", correlationData);
  } catch (error) {
      console.error("Error fetching correlation data:", error);
      res.status(500).json({ error: "Failed to fetch correlation data" });
  }
});

// System health status endpoint
app.get("/api/health", async (req, res) => {
  try {
    const health = {
      status: "ok",
      timestamp: new Date().toISOString(),
      system: {
        hostname: os.hostname(),
        uptime: os.uptime(),
        platform: os.platform(),
        memory: {
          total: os.totalmem(),
          free: os.freemem(),
        }
      },
      services: {
        redis: redisClient.isReady ? "connected" : "disconnected",
        logTailer: logTailer.watching ? "watching" : "stopped"
      }
    };
    res.json(health);
  } catch (error) {
    console.error("Error fetching health status:", error);
    res.status(500).json({ error: "Failed to fetch health status" });
  }
});

// ------------------------------
// API Endpoints for Attack Simulation 
// ------------------------------

// Endpoint to handle simulated attacks from attack-simulation.js
app.post('/api/simulateAttack', async (req, res) => {
  try {
    const simulatedAttacks = req.body;
    
    if (!Array.isArray(simulatedAttacks)) {
      return res.status(400).json({ error: 'Expected an array of attack objects' });
    }
    
    console.log(`Received ${simulatedAttacks.length} simulated attacks`);
    
    // Process each attack as if it came from Suricata
    for (const attack of simulatedAttacks) {
      // Add event_type if not present
      if (!attack.event_type) {
        attack.event_type = 'alert';
      }
      
      // Format the alert structure if needed
      if (!attack.alert && attack.msg) {
        attack.alert = {
          signature: attack.msg,
          signature_id: attack.signature_id || 0,
          category: attack.category || 'unknown',
          severity: attack.severity || 1,
          action: attack.action || 'allowed'
        };
      }
      
      // Process the attack through our normal pipeline
      processLogEntry(attack);
    }
    
    // Also generate an anomaly score spike for the attack
    const anomalyScore = {
      event_type: 'anomaly',
      score: Math.random() * 0.5 + 0.3, // Score between 0.3 and 0.8
      timestamp: new Date().toISOString()
    };
    
    processLogEntry(anomalyScore);
    
    res.status(200).json({ 
      success: true, 
      message: `Processed ${simulatedAttacks.length} attacks` 
    });
  } catch (error) {
    console.error('Error processing simulated attacks:', error);
    res.status(500).json({ error: 'Failed to process simulated attacks' });
  }
});

// ------------------------------
// Start the Server with Socket.IO
// ------------------------------
io.on("connection", async (socket) => {
  console.log("New client connected");
  
  // Send initial data
  const scores = await getAnomalyScoresFromRedis();
  socket.emit("update", scores);
  
  const alerts = await getAlertsFromRedis();
  socket.emit("alertUpdate", alerts);
  
  const trafficData = await getTrafficData();
  socket.emit("trafficUpdate", trafficData);
  
  const distribution = await getAlertDistribution();
  socket.emit("alertDistributionUpdate", distribution);
  
  const correlationData = await getCorrelationData();
  socket.emit("correlationUpdate", correlationData);
  
  // Handle disconnection
  socket.on("disconnect", () => {
    console.log("Client disconnected");
  });
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  
  // Stop the log tailer
  if (logTailer) {
    logTailer.stop();
  }
  
  // Close Redis connection
  if (redisClient.isReady) {
    await redisClient.quit();
  }
  
  // Close the server
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
  
  // Force exit after 5 seconds if server hasn't closed
  setTimeout(() => {
    console.log('Forcing shutdown after timeout');
    process.exit(1);
  }, 5000);
});

server.listen(port, () => {
  console.log(`Server listening on port ${port}`);
  console.log(`Watching Suricata EVE log at: ${logPath}`);
});