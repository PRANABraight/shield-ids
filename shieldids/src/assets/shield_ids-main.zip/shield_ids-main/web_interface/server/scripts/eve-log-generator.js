#!/usr/bin/env node

/**
 * Suricata EVE JSON Log Generator for Testing
 * 
 * This script generates simulated Suricata EVE JSON log entries for testing
 * the SHIELD IDS dashboard. It will create both alert entries and anomaly score
 * entries to simulate a real environment.
 * 
 * Usage:
 *   node eve-log-generator.js [output-file] [interval-ms]
 * 
 * Options:
 *   output-file: Path to write logs (default: ./test-eve.json)
 *   interval-ms: Milliseconds between log entries (default: 2000)
 */

const fs = require('fs');
const path = require('path');

// Command line arguments
const outputFile = process.argv[2] || path.join(__dirname, 'test-eve.json');
const intervalMs = parseInt(process.argv[3]) || 2000;

// Create or truncate the output file
if (!fs.existsSync(path.dirname(outputFile))) {
  fs.mkdirSync(path.dirname(outputFile), { recursive: true });
}
fs.writeFileSync(outputFile, '');

console.log(`Generating Suricata EVE logs to: ${outputFile}`);
console.log(`Interval: ${intervalMs}ms`);

// Sample alert templates
const alertTemplates = [
  {
    msg: "ET EXPLOIT Possible MS17-010 Echo Response",
    category: "attempted-admin",
    severity: 1
  },
  {
    msg: "INDICATOR-SCAN SSH brute force login attempt",
    category: "attempted-user",
    severity: 2
  },
  {
    msg: "ET POLICY SMB2 NT Create AndX Request For an Executable File",
    category: "policy-violation",
    severity: 3
  },
  {
    msg: "ET POLICY DNS Query to .top TLD - Potential Malware Domain",
    category: "bad-unknown",
    severity: 2
  },
  {
    msg: "ET TROJAN Potential Malicious SSL Certificate Detected",
    category: "trojan-activity",
    severity: 1
  },
  {
    msg: "ET WEB_SERVER Possible CVE-2021-44228 Log4j Attack",
    category: "web-application-attack",
    severity: 1
  }
];

// Sample IP addresses
const sourceIPs = [
  "192.168.1.100", "10.0.0.15", "172.16.0.32", "192.168.0.5",
  "45.33.32.156", "193.27.14.99", "91.234.36.51", "121.18.238.114"
];

const destIPs = [
  "192.168.1.1", "10.0.0.1", "172.16.0.1", "192.168.0.1",
  "142.250.74.110", "104.18.23.19", "172.217.20.174", "151.101.65.5"
];

// Sample protocols
const protocols = ["TCP", "UDP", "HTTP", "ICMP", "DNS", "TLS"];

// Generate a random anomaly score with trend pattern
let trendDirection = 1;
let baseAnomalyScore = 0.1;

function getAnomalyScore() {
  // Add some randomness to the base score
  const randomFactor = Math.random() * 0.1;
  
  // Update base score according to trend
  baseAnomalyScore = baseAnomalyScore + (trendDirection * 0.02) + randomFactor;
  
  // Keep scores within bounds
  if (baseAnomalyScore > 0.95) {
    trendDirection = -1;
    baseAnomalyScore = 0.95;
  } else if (baseAnomalyScore < 0.05) {
    trendDirection = 1;
    baseAnomalyScore = 0.05;
  }
  
  // Occasionally change direction
  if (Math.random() < 0.1) {
    trendDirection *= -1;
  }
  
  // Occasionally spike the score
  if (Math.random() < 0.05) {
    return Math.min(Math.random() * 0.5 + 0.5, 0.99);
  }
  
  return parseFloat(baseAnomalyScore.toFixed(3));
}

// Generate a random alert entry
function generateAlertEntry() {
  const template = alertTemplates[Math.floor(Math.random() * alertTemplates.length)];
  const srcIp = sourceIPs[Math.floor(Math.random() * sourceIPs.length)];
  const destIp = destIPs[Math.floor(Math.random() * destIPs.length)];
  const proto = protocols[Math.floor(Math.random() * protocols.length)];
  
  return {
    timestamp: new Date().toISOString(),
    event_type: "alert",
    src_ip: srcIp,
    dest_ip: destIp,
    proto: proto,
    alert: {
      signature: template.msg,
      signature_id: Math.floor(Math.random() * 3000000) + 2000000,
      category: template.category,
      severity: template.severity,
      action: "allowed"
    },
    http: proto === "HTTP" ? {
      hostname: "example.com",
      url: "/index.php",
      http_method: "GET",
      status: 200
    } : undefined,
    app_proto: proto === "HTTP" ? "http" : undefined
  };
}

// Generate an anomaly score entry
function generateAnomalyEntry() {
  return {
    timestamp: new Date().toISOString(),
    event_type: "anomaly",
    score: getAnomalyScore(),
    src_ip: sourceIPs[Math.floor(Math.random() * sourceIPs.length)],
    dest_ip: destIPs[Math.floor(Math.random() * destIPs.length)]
  };
}

// Write entry to the EVE JSON log file
function writeLogEntry(entry) {
  fs.appendFileSync(outputFile, JSON.stringify(entry) + '\n');
  console.log(`[${entry.event_type}] ${entry.timestamp} - ${entry.event_type === 'anomaly' ? `Score: ${entry.score}` : entry.alert.signature}`);
}

// Generate log entries at the specified interval
let entryCount = 0;
setInterval(() => {
  entryCount++;
  
  // Always generate an anomaly score every interval
  const anomalyEntry = generateAnomalyEntry();
  writeLogEntry(anomalyEntry);
  
  // Generate alerts less frequently (roughly every 3rd entry)
  if (Math.random() < 0.3) {
    const alertEntry = generateAlertEntry();
    writeLogEntry(alertEntry);
  }
  
  // Notify about progress
  if (entryCount % 10 === 0) {
    console.log(`Generated ${entryCount} entries so far...`);
  }
}, intervalMs);

console.log('Log generator started. Press Ctrl+C to stop.');

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log(`\nLog generator stopped. Generated ${entryCount} entries.`);
  process.exit(0);
}); 