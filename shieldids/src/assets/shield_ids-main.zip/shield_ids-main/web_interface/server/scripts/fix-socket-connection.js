#!/usr/bin/env node

/**
 * Socket.IO Connection Troubleshooter
 * 
 * This script helps diagnose and fix Socket.IO connection issues between
 * the client and server. It checks for common problems and provides solutions.
 * 
 * Usage:
 *   node fix-socket-connection.js [options]
 * 
 * Options:
 *   --server-port <port>   Test server port (default: 5050)
 *   --client-port <port>   Client port (default: 3000)
 */

const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const { io: Client } = require('socket.io-client');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { program } = require('commander');
const { exec } = require('child_process');

// Parse command line arguments
program
  .option('--server-port <port>', 'Server port to test', 5050)
  .option('--client-port <port>', 'Client port', 3000)
  .option('--api-file <path>', 'Path to client API file', '../client/src/api.js')
  .parse(process.argv);

const options = program.opts();
const SERVER_PORT = parseInt(options.serverPort);
const CLIENT_PORT = parseInt(options.clientPort);
const API_FILE_PATH = path.resolve(__dirname, options.apiFile);

// ASCII colors for console output
const COLORS = {
  GREEN: '\x1b[32m',
  YELLOW: '\x1b[33m',
  RED: '\x1b[31m',
  BLUE: '\x1b[34m',
  RESET: '\x1b[0m',
  BOLD: '\x1b[1m'
};

// Print header
console.log(`${COLORS.BOLD}${COLORS.BLUE}==================================${COLORS.RESET}`);
console.log(`${COLORS.BOLD}${COLORS.BLUE}Socket.IO Connection Troubleshooter${COLORS.RESET}`);
console.log(`${COLORS.BOLD}${COLORS.BLUE}==================================${COLORS.RESET}\n`);

// Step 1: Check if server port is in use
function checkServerPort() {
  console.log(`${COLORS.BOLD}[1] Checking if server port ${SERVER_PORT} is in use...${COLORS.RESET}`);
  
  return new Promise((resolve) => {
    const testServer = http.createServer();
    
    testServer.once('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.log(`${COLORS.YELLOW}✗ Port ${SERVER_PORT} is already in use.${COLORS.RESET}`);
        
        // Try to identify what's using the port
        exec(`lsof -i :${SERVER_PORT}`, (error, stdout) => {
          if (!error && stdout) {
            console.log(`${COLORS.YELLOW}The following process is using port ${SERVER_PORT}:${COLORS.RESET}`);
            console.log(stdout);
          }
          
          resolve(false);
        });
      } else {
        console.log(`${COLORS.RED}✗ Error checking port: ${err.message}${COLORS.RESET}`);
        resolve(false);
      }
    });
    
    testServer.once('listening', () => {
      console.log(`${COLORS.GREEN}✓ Port ${SERVER_PORT} is available.${COLORS.RESET}`);
      testServer.close();
      resolve(true);
    });
    
    testServer.listen(SERVER_PORT);
  });
}

// Step 2: Check if client API file exists and contains correct API URL
function checkApiFile() {
  console.log(`\n${COLORS.BOLD}[2] Checking client API configuration...${COLORS.RESET}`);
  
  try {
    if (!fs.existsSync(API_FILE_PATH)) {
      console.log(`${COLORS.RED}✗ API file not found at: ${API_FILE_PATH}${COLORS.RESET}`);
      return false;
    }
    
    const apiContent = fs.readFileSync(API_FILE_PATH, 'utf8');
    
    // Check if API_URL is defined correctly
    if (!apiContent.includes('API_URL')) {
      console.log(`${COLORS.RED}✗ API_URL not found in API file${COLORS.RESET}`);
      return false;
    }
    
    // Parse the API_URL value - this is rough but should work for most cases
    const urlMatch = apiContent.match(/API_URL\s*=\s*[^"]*["']([^"']+)["']/);
    if (!urlMatch) {
      console.log(`${COLORS.RED}✗ Could not parse API_URL from API file${COLORS.RESET}`);
      return false; 
    }
    
    const apiUrl = urlMatch[1];
    console.log(`${COLORS.GREEN}✓ Found API_URL: ${apiUrl}${COLORS.RESET}`);
    
    // Check if it contains the correct port
    if (!apiUrl.includes(`:${SERVER_PORT}`)) {
      console.log(`${COLORS.YELLOW}✗ API_URL does not contain the expected port ${SERVER_PORT}${COLORS.RESET}`);
      console.log(`${COLORS.YELLOW}Consider updating the API_URL to include http://localhost:${SERVER_PORT}${COLORS.RESET}`);
      return false;
    }
    
    console.log(`${COLORS.GREEN}✓ API_URL has correct port configuration${COLORS.RESET}`);
    
    // Check if socket options are properly configured
    if (!apiContent.includes('transports:')) {
      console.log(`${COLORS.YELLOW}✗ No Socket.IO transport configuration found${COLORS.RESET}`);
      return false;
    }
    
    if (apiContent.includes("transports: ['websocket']")) {
      console.log(`${COLORS.YELLOW}⚠ Socket.IO is configured to use ONLY WebSocket transport${COLORS.RESET}`);
      console.log(`${COLORS.YELLOW}This can cause issues in some environments. Consider adding polling as fallback.${COLORS.RESET}`);
    } else if (apiContent.includes("transports: ['websocket', 'polling']")) {
      console.log(`${COLORS.GREEN}✓ Socket.IO has WebSocket with polling fallback${COLORS.RESET}`);
    }
    
    return true;
  } catch (error) {
    console.log(`${COLORS.RED}✗ Error checking API file: ${error.message}${COLORS.RESET}`);
    return false;
  }
}

// Step 3: Test Socket.IO connection
async function testSocketConnection() {
  console.log(`\n${COLORS.BOLD}[3] Testing Socket.IO connection...${COLORS.RESET}`);
  
  return new Promise((resolve) => {
    // Create a test server with Socket.IO
    const app = express();
    app.use(cors());
    const server = http.createServer(app);
    const io = new Server(server, {
      cors: {
        origin: `http://localhost:${CLIENT_PORT}`,
        methods: ["GET", "POST"],
        credentials: true
      }
    });
    
    // Socket.IO event handlers
    io.on('connection', (socket) => {
      console.log(`${COLORS.GREEN}✓ Client connected to test server!${COLORS.RESET}`);
      
      // Send a test event
      socket.emit('testEvent', { status: 'success' });
      
      // Respond to ping
      socket.on('ping', () => {
        socket.emit('pong', { time: new Date().toISOString() });
      });
    });
    
    // Start the server
    server.listen(SERVER_PORT, () => {
      console.log(`${COLORS.GREEN}✓ Test server started on port ${SERVER_PORT}${COLORS.RESET}`);
      
      // Try to connect as a client
      try {
        const socket = Client(`http://localhost:${SERVER_PORT}`, {
          transports: ['websocket', 'polling']
        });
        
        socket.on('connect', () => {
          console.log(`${COLORS.GREEN}✓ Test client connected successfully!${COLORS.RESET}`);
          
          // Send a ping and wait for pong
          socket.emit('ping');
        });
        
        socket.on('pong', (data) => {
          console.log(`${COLORS.GREEN}✓ Received pong: ${data.time}${COLORS.RESET}`);
          console.log(`${COLORS.GREEN}✓ Socket.IO bidirectional communication is working!${COLORS.RESET}`);
          
          // Clean up
          socket.disconnect();
          server.close();
          resolve(true);
        });
        
        socket.on('connect_error', (error) => {
          console.log(`${COLORS.RED}✗ Connection error: ${error.message}${COLORS.RESET}`);
          socket.disconnect();
          server.close();
          resolve(false);
        });
        
        // Set a timeout in case we never get a connection
        setTimeout(() => {
          if (socket.connected) return;
          console.log(`${COLORS.RED}✗ Connection timeout after 5 seconds${COLORS.RESET}`);
          socket.disconnect();
          server.close();
          resolve(false);
        }, 5000);
      } catch (error) {
        console.log(`${COLORS.RED}✗ Error creating test client: ${error.message}${COLORS.RESET}`);
        server.close();
        resolve(false);
      }
    });
  });
}

// Step 4: Update API file with correct configuration
function fixApiFile() {
  console.log(`\n${COLORS.BOLD}[4] Updating client API configuration...${COLORS.RESET}`);
  
  try {
    if (!fs.existsSync(API_FILE_PATH)) {
      console.log(`${COLORS.RED}✗ Cannot fix API file: File not found${COLORS.RESET}`);
      return false;
    }
    
    // Create backup
    const backupPath = `${API_FILE_PATH}.backup`;
    fs.copyFileSync(API_FILE_PATH, backupPath);
    console.log(`${COLORS.GREEN}✓ Created backup at ${backupPath}${COLORS.RESET}`);
    
    // Read the current file
    let content = fs.readFileSync(API_FILE_PATH, 'utf8');
    
    // Update the file with proper configuration
    const updatedContent = `// src/api.js

// Use the API URL from environment variable or default to localhost:${SERVER_PORT}
export const API_URL = process.env.REACT_APP_API_URL || "http://localhost:${SERVER_PORT}";

// Socket.IO configuration
export const SOCKET_OPTIONS = {
  transports: ['websocket', 'polling'], // Try WebSocket first, fallback to polling
  reconnectionAttempts: 5,
  reconnectionDelay: 1000,
  timeout: 10000
};

export function getSocketUrl() {
  return API_URL;
}

${content.split('export async function')[1] ? 'export async function' + content.split('export async function')[1] : ''}`;
    
    // Write the updated content
    fs.writeFileSync(API_FILE_PATH, updatedContent);
    console.log(`${COLORS.GREEN}✓ Updated API file with correct configuration${COLORS.RESET}`);
    
    return true;
  } catch (error) {
    console.log(`${COLORS.RED}✗ Error updating API file: ${error.message}${COLORS.RESET}`);
    return false;
  }
}

// Step 5: Provide solutions
function provideSolutions(isServerPortFree, isApiConfigCorrect, isSocketWorking) {
  console.log(`\n${COLORS.BOLD}${COLORS.BLUE}==================================${COLORS.RESET}`);
  console.log(`${COLORS.BOLD}${COLORS.BLUE}Troubleshooting Results${COLORS.RESET}`);
  console.log(`${COLORS.BOLD}${COLORS.BLUE}==================================${COLORS.RESET}\n`);
  
  const issues = [];
  
  if (!isServerPortFree) {
    issues.push(`${COLORS.RED}✗ Port ${SERVER_PORT} is in use by another process${COLORS.RESET}`);
  }
  
  if (!isApiConfigCorrect) {
    issues.push(`${COLORS.RED}✗ Client API configuration needs to be updated${COLORS.RESET}`);
  }
  
  if (!isSocketWorking) {
    issues.push(`${COLORS.RED}✗ Socket.IO connection test failed${COLORS.RESET}`);
  }
  
  if (issues.length === 0) {
    console.log(`${COLORS.GREEN}${COLORS.BOLD}✓ No issues detected! Socket.IO should be working correctly.${COLORS.RESET}`);
    return;
  }
  
  console.log(`${COLORS.BOLD}The following issues were detected:${COLORS.RESET}`);
  issues.forEach(issue => console.log(`- ${issue}`));
  
  console.log(`\n${COLORS.BOLD}Recommended actions:${COLORS.RESET}`);
  
  if (!isServerPortFree) {
    console.log(`
1. ${COLORS.YELLOW}Free up port ${SERVER_PORT}:${COLORS.RESET}
   Kill the process using port ${SERVER_PORT} with:
   \`\`\`
   kill $(lsof -t -i:${SERVER_PORT})
   \`\`\`
   
   Or use a different port for the server by updating start.sh:
   \`\`\`
   ./start.sh --server-port 5051 --generate-logs
   \`\`\`
`);
  }
  
  if (!isApiConfigCorrect) {
    console.log(`
${!isServerPortFree ? '2' : '1'}. ${COLORS.YELLOW}Fix client API configuration:${COLORS.RESET}
   Run this script with fix option to update the API file:
   \`\`\`
   node fix-socket-connection.js --api-file ${options.apiFile} --fix
   \`\`\`
   
   Or manually update ${API_FILE_PATH} to use:
   - API_URL = "http://localhost:${SERVER_PORT}"
   - SOCKET_OPTIONS with both 'websocket' and 'polling' transports
`);
  }
  
  if (!isSocketWorking) {
    console.log(`
${!isServerPortFree && !isApiConfigCorrect ? '3' : (!isServerPortFree || !isApiConfigCorrect ? '2' : '1')}. ${COLORS.YELLOW}Check server setup:${COLORS.RESET}
   - Verify the server is running correctly:
     \`\`\`
     cd ../..
     ./start.sh --generate-logs
     \`\`\`

   - Check browser console for specific connection errors

   - Try with a different browser to rule out browser extensions interfering
     
   - Make sure firewall isn't blocking WebSocket connections
`);
  }
  
  console.log(`\n${COLORS.BOLD}After making changes, restart both server and client.${COLORS.RESET}`);
}

// Main function
async function main() {
  // Step 1: Check if server port is free
  const isServerPortFree = await checkServerPort();
  
  // Step 2: Check API file
  const isApiConfigCorrect = checkApiFile();
  
  // Step 3: Test Socket.IO connection (only if port is free)
  const isSocketWorking = isServerPortFree ? await testSocketConnection() : false;
  
  // If API config is incorrect and user requested fix
  if (!isApiConfigCorrect && program.args.includes('--fix')) {
    fixApiFile();
  }
  
  // Step 5: Provide solutions
  provideSolutions(isServerPortFree, isApiConfigCorrect, isSocketWorking);
}

// Run the main function
main().catch(error => {
  console.error(`${COLORS.RED}ERROR: ${error.message}${COLORS.RESET}`);
}); 