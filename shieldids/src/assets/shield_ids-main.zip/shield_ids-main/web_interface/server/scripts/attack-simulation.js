#!/usr/bin/env node

/**
 * Attack Simulation Script for SHIELD IDS Testing
 * 
 * This script generates realistic attack traffic for testing the 
 * real-time detection capabilities of the SHIELD IDS system.
 * 
 * Usage:
 *   node attack-simulation.js [options]
 * 
 * Options:
 *   --interval <ms>      Interval between attacks in milliseconds (default: 5000)
 *   --duration <sec>     Duration of the simulation in seconds (default: 60)
 *   --target <ip>        Target IP address (default: 192.168.1.100)
 *   --source <ip>        Source IP address (default: randomized)
 *   --output <path>      Output to a specific path instead of system logs
 */

const fs = require('fs');
const path = require('path');
const { program } = require('commander');
const { spawn } = require('child_process');
const { networkInterfaces } = require('os');

// Parse command line arguments
program
  .option('--interval <ms>', 'Interval between attacks in milliseconds', 5000)
  .option('--duration <sec>', 'Duration of the simulation in seconds', 60)
  .option('--target <ip>', 'Target IP address', '192.168.1.100')
  .option('--source <ip>', 'Source IP address (default: randomized)')
  .option('--output <path>', 'Output path for simulated logs')
  .parse(process.argv);

const options = program.opts();

// Configuration
const INTERVAL = parseInt(options.interval);
const DURATION = parseInt(options.duration) * 1000;
const TARGET_IP = options.target;
const SOURCE_IP = options.source || getRandomIP();
const OUTPUT_PATH = options.output || null;
const START_TIME = Date.now();

// Attack types with their configurations
const ATTACK_TYPES = [
  {
    name: 'Port Scan',
    category: 'recon',
    severity: 1,
    description: 'TCP port scan detected',
    simulate: () => generatePortScanAlert()
  },
  {
    name: 'SQL Injection',
    category: 'web-application-attack',
    severity: 2,
    description: 'SQL injection attempt detected',
    simulate: () => generateWebAttackAlert('sql_injection')
  },
  {
    name: 'Cross-Site Scripting',
    category: 'web-application-attack',
    severity: 2,
    description: 'XSS attack detected',
    simulate: () => generateWebAttackAlert('xss')
  },
  {
    name: 'Brute Force',
    category: 'authentication',
    severity: 2,
    description: 'Multiple authentication failures',
    simulate: () => generateBruteForceAlert()
  },
  {
    name: 'Command Injection',
    category: 'exploit',
    severity: 3,
    description: 'Command injection attempt detected',
    simulate: () => generateExploitAlert('command_injection')
  },
  {
    name: 'DDoS',
    category: 'dos',
    severity: 3,
    description: 'Possible DDoS attack detected',
    simulate: () => generateDDoSAlert()
  }
];

// Get local IP for more realistic simulation
function getLocalIP() {
  const interfaces = networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

// Generate random IP for attack sources
function getRandomIP() {
  const segment1 = Math.floor(Math.random() * 223) + 1;
  const segment2 = Math.floor(Math.random() * 255);
  const segment3 = Math.floor(Math.random() * 255);
  const segment4 = Math.floor(Math.random() * 254) + 1;
  return `${segment1}.${segment2}.${segment3}.${segment4}`;
}

// Generate a random port
function getRandomPort() {
  return Math.floor(Math.random() * 65535) + 1;
}

// Generate a random HTTP user agent
function getRandomUserAgent() {
  const userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36'
  ];
  return userAgents[Math.floor(Math.random() * userAgents.length)];
}

// Generate a timestamp in the EVE JSON format
function getTimestamp() {
  return new Date().toISOString();
}

// Generate a port scan alert
function generatePortScanAlert() {
  const srcPort = getRandomPort();
  const destPorts = [];
  const numPorts = Math.floor(Math.random() * 20) + 10; // Scan 10-30 ports
  
  for (let i = 0; i < numPorts; i++) {
    destPorts.push(getRandomPort());
  }
  
  const alerts = [];
  for (const destPort of destPorts) {
    alerts.push({
      timestamp: getTimestamp(),
      src_ip: SOURCE_IP || getRandomIP(),
      src_port: srcPort,
      dest_ip: TARGET_IP,
      dest_port: destPort,
      proto: 'TCP',
      event_type: 'alert',
      category: 'recon',
      severity: 1,
      signature_id: 1001,
      msg: 'ET SCAN Potential Port Scan',
      payload: null,
      action: 'allowed'
    });
  }
  
  return alerts;
}

// Generate a web attack alert (SQL injection, XSS, etc.)
function generateWebAttackAlert(attackType) {
  const destPort = 80;
  const srcPort = getRandomPort();
  
  let payload, signature, signatureId;
  
  if (attackType === 'sql_injection') {
    payload = "GET /search?q=' OR 1=1 --";
    signature = 'ET WEB_SERVER SQL Injection Attempt';
    signatureId = 2001;
  } else if (attackType === 'xss') {
    payload = "GET /comment?text=<script>alert('XSS')</script>";
    signature = 'ET WEB_SERVER Cross Site Scripting Attempt';
    signatureId = 2002;
  } else {
    payload = "GET /admin.php?debug=true";
    signature = 'ET WEB_SERVER Suspicious Access Attempt';
    signatureId = 2003;
  }
  
  return [{
    timestamp: getTimestamp(),
    src_ip: SOURCE_IP || getRandomIP(),
    src_port: srcPort,
    dest_ip: TARGET_IP,
    dest_port: destPort,
    proto: 'TCP',
    app_proto: 'http',
    event_type: 'alert',
    http: {
      hostname: TARGET_IP,
      url: payload.split(' ')[1],
      http_method: 'GET',
      http_user_agent: getRandomUserAgent()
    },
    category: 'web-application-attack',
    severity: 2,
    signature_id: signatureId,
    msg: signature,
    payload: payload,
    action: 'allowed'
  }];
}

// Generate a brute force attack alert
function generateBruteForceAlert() {
  const destPort = 22; // SSH
  const alerts = [];
  const numAttempts = Math.floor(Math.random() * 5) + 3; // 3-7 attempts
  
  for (let i = 0; i < numAttempts; i++) {
    alerts.push({
      timestamp: getTimestamp(),
      src_ip: SOURCE_IP || getRandomIP(),
      src_port: getRandomPort(),
      dest_ip: TARGET_IP,
      dest_port: destPort,
      proto: 'TCP',
      app_proto: 'ssh',
      event_type: 'alert',
      category: 'authentication',
      severity: 2,
      signature_id: 3001,
      msg: 'ET BRUTEFORCE SSH Brute Force Attempt',
      payload: null,
      action: 'allowed'
    });
  }
  
  return alerts;
}

// Generate an exploit alert
function generateExploitAlert(exploitType) {
  let destPort, payload, signature, signatureId;
  
  if (exploitType === 'command_injection') {
    destPort = 80;
    payload = "GET /cgi-bin/status?cmd=cat%20/etc/passwd";
    signature = 'ET EXPLOIT Command Injection Attempt';
    signatureId = 4001;
  } else {
    destPort = 445; // SMB
    payload = null;
    signature = 'ET EXPLOIT Possible Buffer Overflow Attempt';
    signatureId = 4002;
  }
  
  return [{
    timestamp: getTimestamp(),
    src_ip: SOURCE_IP || getRandomIP(),
    src_port: getRandomPort(),
    dest_ip: TARGET_IP,
    dest_port: destPort,
    proto: 'TCP',
    event_type: 'alert',
    category: 'exploit',
    severity: 3,
    signature_id: signatureId,
    msg: signature,
    payload: payload,
    action: 'allowed'
  }];
}

// Generate a DDoS attack alert
function generateDDoSAlert() {
  const alerts = [];
  const numPackets = Math.floor(Math.random() * 10) + 5; // 5-15 packets
  const destPort = 80;
  
  for (let i = 0; i < numPackets; i++) {
    alerts.push({
      timestamp: getTimestamp(),
      src_ip: getRandomIP(), // Multiple source IPs for DDoS
      src_port: getRandomPort(),
      dest_ip: TARGET_IP,
      dest_port: destPort,
      proto: 'UDP',
      event_type: 'alert',
      category: 'dos',
      severity: 3,
      signature_id: 5001,
      msg: 'ET DOS Possible UDP Flood',
      payload: null,
      action: 'allowed'
    });
  }
  
  return alerts;
}

// Generate an anomaly score entry
function generateAnomalyScore() {
  // Fluctuate score to simulate real data
  // Occasional high spikes during attacks
  let baseScore = Math.random() * 0.3; // Base level 0-0.3
  
  // If an attack is happening, increase the score
  if (Math.random() > 0.7) {
    baseScore += Math.random() * 0.5; // Add 0-0.5
  }
  
  return {
    timestamp: getTimestamp(),
    score: baseScore,
    time: new Date().toLocaleTimeString()
  };
}

// Main function to simulate attacks
function simulateAttacks() {
  console.log("Starting attack simulation...");
  console.log(`Target IP: ${TARGET_IP}`);
  console.log(`Source IP: ${SOURCE_IP || "Random"}`);
  console.log(`Duration: ${DURATION/1000} seconds`);
  console.log(`Interval: ${INTERVAL} ms`);
  
  if (OUTPUT_PATH) {
    console.log(`Writing to: ${OUTPUT_PATH}`);
    // Ensure the output file exists and is empty
    fs.writeFileSync(OUTPUT_PATH, '');
  }
  
  let attackCount = 0;
  
  // Generate attack logs at the specified interval
  const intervalId = setInterval(() => {
    // Check if we've hit the duration limit
    if (Date.now() - START_TIME >= DURATION) {
      clearInterval(intervalId);
      console.log(`Simulation complete. Generated ${attackCount} attacks.`);
      return;
    }
    
    // Pick a random attack type
    const attackType = ATTACK_TYPES[Math.floor(Math.random() * ATTACK_TYPES.length)];
    
    // Generate the attack alert(s)
    const alerts = attackType.simulate();
    
    // Generate an anomaly score
    const anomalyScore = generateAnomalyScore();
    
    // Process the generated alerts
    if (OUTPUT_PATH) {
      // Write to the specified log file
      for (const alert of alerts) {
        fs.appendFileSync(OUTPUT_PATH, JSON.stringify({
          ...alert,
          alert: {
            action: alert.action,
            signature: alert.msg,
            signature_id: alert.signature_id
          }
        }) + '\n');
      }
      
      // Also write the anomaly score
      fs.appendFileSync(OUTPUT_PATH, JSON.stringify({
        event_type: "anomaly",
        ...anomalyScore
      }) + '\n');
    } else {
      // Not writing to file, send to the console for inspection
      console.log(`[${new Date().toLocaleTimeString()}] Generated ${alerts.length} alerts for attack: ${attackType.name}`);
      
      // Attempt to send to the server via a socket or API
      try {
        const localIp = getLocalIP();
        const postData = JSON.stringify(alerts);
        const request = require('http').request({
          hostname: 'localhost',
          port: 5050,
          path: '/api/simulateAttack',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData)
          }
        }, (res) => {
          let data = '';
          res.on('data', (chunk) => {
            data += chunk;
          });
          res.on('end', () => {
            if (res.statusCode === 200) {
              console.log(`Successfully sent attack to server: ${attackType.name}`);
            } else {
              console.error(`Failed to send attack to server: ${res.statusCode} ${data}`);
            }
          });
        });
        
        request.on('error', (e) => {
          console.error(`Error sending attack to server: ${e.message}`);
        });
        
        request.write(postData);
        request.end();
      } catch (error) {
        console.error("Error sending attack data to server:", error.message);
      }
    }
    
    attackCount += alerts.length;
  }, INTERVAL);
  
  // Handle graceful shutdown
  process.on('SIGINT', () => {
    clearInterval(intervalId);
    console.log(`\nSimulation stopped. Generated ${attackCount} attacks.`);
    process.exit(0);
  });
}

// Start the simulation
simulateAttacks(); 