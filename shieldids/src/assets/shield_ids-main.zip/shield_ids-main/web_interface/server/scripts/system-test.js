#!/usr/bin/env node

/**
 * SHIELD IDS System Test Script
 * 
 * This script tests the main components of the SHIELD IDS system:
 * - Log file monitoring and ingestion
 * - Socket.IO event emission
 * - Backend API functionality
 * - Redis data storage
 * 
 * Usage:
 *   node system-test.js [options]
 * 
 * Options:
 *   --log-file <path>      Path to the Suricata eve.json log file to test with (default: ./test-eve.json)
 *   --server-url <url>     URL of the SHIELD IDS server (default: http://localhost:5050)
 *   --generate-logs        Generate test logs during the test
 *   --test-duration <sec>  Duration of the test in seconds (default: 60)
 *   --verbose              Enable verbose logging
 */

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const axios = require('axios');
const io = require('socket.io-client');
const { program } = require('commander');
const ora = require('ora');
const chalk = require('chalk');

// Parse command line arguments
program
  .option('--log-file <path>', 'Path to the Suricata eve.json log file', './test-eve.json')
  .option('--server-url <url>', 'URL of the SHIELD IDS server', 'http://localhost:5050')
  .option('--generate-logs', 'Generate test logs during the test')
  .option('--test-duration <sec>', 'Duration of the test in seconds', 60)
  .option('--verbose', 'Enable verbose logging')
  .parse(process.argv);

const options = program.opts();
const VERBOSE = options.verbose;
const LOG_FILE = path.resolve(options.logFile);
const SERVER_URL = options.serverUrl;
const TEST_DURATION = parseInt(options.testDuration);

// Status counters
const stats = {
  socketEvents: {
    update: 0,
    alertUpdate: 0,
    trafficUpdate: 0,
    alertDistributionUpdate: 0,
    connectionEvents: 0
  },
  apiCalls: {
    success: 0,
    failed: 0
  },
  logEntries: 0
};

// Test result tracking
const testResults = {
  logIngestion: false,
  socketConnection: false,
  socketEvents: false,
  apiEndpoints: false,
  overallSuccess: false
};

/**
 * Log a message if verbose mode is enabled
 */
function verboseLog(message) {
  if (VERBOSE) {
    console.log(chalk.gray(`[DEBUG] ${message}`));
  }
}

/**
 * Generate test EVE logs using the eve-log-generator script
 */
async function generateTestLogs() {
  return new Promise((resolve, reject) => {
    const spinner = ora('Generating test logs...').start();
    
    // Create a test directory if it doesn't exist
    const testDir = path.dirname(LOG_FILE);
    if (!fs.existsSync(testDir)) {
      fs.mkdirSync(testDir, { recursive: true });
    }
    
    // Start the log generator
    const logGenerator = spawn('node', [
      path.join(__dirname, 'eve-log-generator.js'),
      LOG_FILE,
      '500' // Generate a log entry every 500ms
    ]);
    
    let logData = '';
    
    logGenerator.stdout.on('data', (data) => {
      logData += data.toString();
      verboseLog(`Log generator: ${data.toString().trim()}`);
    });
    
    logGenerator.stderr.on('data', (data) => {
      console.error(chalk.red(`Log generator error: ${data.toString().trim()}`));
    });
    
    logGenerator.on('error', (error) => {
      spinner.fail('Failed to start log generator');
      reject(error);
    });
    
    // Give it some time to generate initial logs
    setTimeout(() => {
      spinner.succeed('Test logs generated');
      resolve(logGenerator);
    }, 3000);
  });
}

/**
 * Test Socket.IO connection and events
 */
async function testSocketConnection() {
  return new Promise((resolve) => {
    const spinner = ora('Testing Socket.IO connection...').start();
    
    const socket = io(SERVER_URL, {
      transports: ['websocket'],
      reconnectionAttempts: 5
    });
    
    const events = ['update', 'alertUpdate', 'trafficUpdate', 'alertDistributionUpdate'];
    let receivedEvents = new Set();
    let resolved = false;
    
    // Set up event listeners
    socket.on('connect', () => {
      stats.socketEvents.connectionEvents++;
      verboseLog('Socket connected');
      testResults.socketConnection = true;
      spinner.text = 'Socket connected, waiting for events...';
    });
    
    socket.on('disconnect', () => {
      stats.socketEvents.connectionEvents++;
      verboseLog('Socket disconnected');
    });
    
    socket.on('connect_error', (error) => {
      stats.socketEvents.connectionEvents++;
      verboseLog(`Socket connection error: ${error.message}`);
      if (!resolved) {
        spinner.fail(`Socket connection failed: ${error.message}`);
        resolved = true;
        resolve(false);
      }
    });
    
    // Listen for the various events
    events.forEach(eventName => {
      socket.on(eventName, (data) => {
        stats.socketEvents[eventName]++;
        receivedEvents.add(eventName);
        verboseLog(`Received ${eventName} event: ${JSON.stringify(data).slice(0, 100)}...`);
        
        // Check if we've received all event types
        if (!resolved && events.every(e => receivedEvents.has(e))) {
          testResults.socketEvents = true;
          spinner.succeed('All Socket.IO events received');
          resolved = true;
          resolve(true);
        }
      });
    });
    
    // Set a timeout in case we don't receive all events
    setTimeout(() => {
      if (!resolved) {
        const received = Array.from(receivedEvents);
        const missing = events.filter(e => !receivedEvents.has(e));
        
        if (received.length > 0) {
          testResults.socketEvents = received.length === events.length;
          spinner.warn(`Received ${received.length}/${events.length} event types. Missing: ${missing.join(', ')}`);
        } else {
          spinner.fail('No Socket.IO events received within timeout');
        }
        
        resolved = true;
        resolve(received.length > 0);
      }
    }, TEST_DURATION * 1000 * 0.7); // 70% of the test duration
  });
}

/**
 * Test the backend API endpoints
 */
async function testApiEndpoints() {
  const spinner = ora('Testing API endpoints...').start();
  
  const endpoints = [
    '/api/anomalyScores',
    '/api/alerts',
    '/api/trafficVolume',
    '/api/alertDistribution',
    '/api/stats',
    '/api/health'
  ];
  
  const results = await Promise.all(endpoints.map(async (endpoint) => {
    try {
      const response = await axios.get(`${SERVER_URL}${endpoint}`);
      stats.apiCalls.success++;
      verboseLog(`API ${endpoint}: ${response.status} ${JSON.stringify(response.data).slice(0, 100)}...`);
      return { endpoint, success: true, status: response.status };
    } catch (error) {
      stats.apiCalls.failed++;
      verboseLog(`API ${endpoint} failed: ${error.message}`);
      return { endpoint, success: false, error: error.message };
    }
  }));
  
  const successful = results.filter(r => r.success);
  testResults.apiEndpoints = successful.length === endpoints.length;
  
  if (testResults.apiEndpoints) {
    spinner.succeed(`All API endpoints (${successful.length}/${endpoints.length}) responded successfully`);
  } else {
    spinner.warn(`${successful.length}/${endpoints.length} API endpoints passed`);
    const failed = results.filter(r => !r.success);
    failed.forEach(({ endpoint, error }) => {
      console.log(chalk.yellow(`  - ${endpoint}: ${error}`));
    });
  }
  
  return testResults.apiEndpoints;
}

/**
 * Check if log file is being properly tailed
 */
async function checkLogTailing() {
  const spinner = ora('Checking log tailing functionality...').start();
  
  return new Promise((resolve) => {
    let lastSize = 0;
    let growthDetected = false;
    let checksPerformed = 0;
    
    const interval = setInterval(() => {
      try {
        const stats = fs.statSync(LOG_FILE);
        const currentSize = stats.size;
        
        checksPerformed++;
        
        if (currentSize > lastSize) {
          growthDetected = true;
          spinner.text = `Log file growing: ${lastSize} -> ${currentSize} bytes`;
          verboseLog(`Log file size increased: ${lastSize} -> ${currentSize} bytes`);
        }
        
        lastSize = currentSize;
        
        // Exit after a few checks
        if (checksPerformed >= 5 || growthDetected) {
          clearInterval(interval);
          testResults.logIngestion = growthDetected;
          
          if (growthDetected) {
            spinner.succeed('Log file is being properly written and should be tailed by the server');
          } else {
            spinner.warn('Log file does not appear to be growing. Check log generation.');
          }
          
          resolve(growthDetected);
        }
      } catch (error) {
        verboseLog(`Error checking log file: ${error.message}`);
        if (checksPerformed >= 5) {
          clearInterval(interval);
          spinner.fail(`Failed to check log file: ${error.message}`);
          testResults.logIngestion = false;
          resolve(false);
        }
      }
    }, 2000);
  });
}

/**
 * Print the final test report
 */
function printTestReport() {
  console.log('\n' + chalk.bold('SHIELD IDS System Test Report'));
  console.log('===============================\n');
  
  // Print test results
  console.log(chalk.bold('Test Results:'));
  console.log(`Log Ingestion: ${testResults.logIngestion ? chalk.green('PASS') : chalk.red('FAIL')}`);
  console.log(`Socket.IO Connection: ${testResults.socketConnection ? chalk.green('PASS') : chalk.red('FAIL')}`);
  console.log(`Socket.IO Events: ${testResults.socketEvents ? chalk.green('PASS') : chalk.yellow('PARTIAL')}`);
  console.log(`API Endpoints: ${testResults.apiEndpoints ? chalk.green('PASS') : chalk.yellow('PARTIAL')}`);
  
  // Print event statistics
  console.log('\n' + chalk.bold('Socket.IO Event Statistics:'));
  Object.entries(stats.socketEvents).forEach(([event, count]) => {
    console.log(`- ${event}: ${count}`);
  });
  
  // Print API statistics
  console.log('\n' + chalk.bold('API Call Statistics:'));
  console.log(`- Successful: ${stats.apiCalls.success}`);
  console.log(`- Failed: ${stats.apiCalls.failed}`);
  
  // Overall result
  testResults.overallSuccess = 
    testResults.logIngestion && 
    testResults.socketConnection && 
    (testResults.socketEvents || stats.socketEvents.update > 0) &&
    (testResults.apiEndpoints || stats.apiCalls.success > 0);
  
  console.log('\n' + chalk.bold('Overall Test Result:'));
  console.log(testResults.overallSuccess ? 
    chalk.green('✓ PASS - System appears to be functioning correctly') : 
    chalk.red('✗ FAIL - System is not functioning as expected')
  );
  
  // Add recommendations if test failed
  if (!testResults.overallSuccess) {
    console.log('\n' + chalk.bold('Recommendations:'));
    
    if (!testResults.logIngestion) {
      console.log('- Check that the Suricata log file exists and is being written to');
      console.log(`  Current log file path: ${LOG_FILE}`);
    }
    
    if (!testResults.socketConnection) {
      console.log('- Verify the Socket.IO server is running and accessible');
      console.log(`  Server URL: ${SERVER_URL}`);
    }
    
    if (!testResults.socketEvents && testResults.socketConnection) {
      console.log('- Check the server\'s event emitters for Socket.IO');
      console.log('- Verify that log entries are being processed and events are being triggered');
    }
    
    if (!testResults.apiEndpoints) {
      console.log('- Check the Express API routes configuration');
      console.log('- Verify Redis connection is working');
    }
  }
}

/**
 * Main function to run all tests
 */
async function runTests() {
  console.log(chalk.bold('SHIELD IDS System Test'));
  console.log(`Server URL: ${SERVER_URL}`);
  console.log(`Log File: ${LOG_FILE}`);
  console.log(`Test Duration: ${TEST_DURATION} seconds\n`);
  
  // Generate logs if requested
  let logGenerator;
  if (options.generateLogs) {
    try {
      logGenerator = await generateTestLogs();
    } catch (error) {
      console.error(chalk.red(`Failed to generate test logs: ${error.message}`));
      process.exit(1);
    }
  }
  
  // Run the tests in parallel
  await Promise.all([
    checkLogTailing(),
    testSocketConnection(),
    testApiEndpoints()
  ]);
  
  // Print the test report
  printTestReport();
  
  // Clean up
  if (logGenerator) {
    logGenerator.kill();
    console.log(chalk.gray('Log generator stopped'));
  }
  
  // Exit with appropriate status code
  process.exit(testResults.overallSuccess ? 0 : 1);
}

// Run the tests
runTests().catch(error => {
  console.error(chalk.red(`Test script error: ${error.message}`));
  process.exit(1);
}); 