// web_interface/client/src/components/StatsSummary.js
import React, { useState, useEffect, useRef } from 'react';
import { Paper, Typography, Grid, Box, Chip } from '@mui/material';
import { io } from 'socket.io-client';
import { API_URL, SOCKET_OPTIONS } from '../api';

const StatsSummary = () => {
  const [stats, setStats] = useState({ totalAlerts: 0, avgAnomalyScore: 0 });
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState(null);
  const socketRef = useRef(null);

  useEffect(() => {
    // Initial fetch
    const fetchStats = async () => {
      try {
        const response = await fetch(`${API_URL}/api/stats`);
        if (!response.ok) throw new Error('Failed to fetch stats');
        const data = await response.json();
        setStats(data);
        setError(null);
      } catch (error) {
        console.error("Error fetching stats:", error);
        setError("Failed to load statistics");
      }
    };

    fetchStats();

    // Connect to Socket.IO for real-time updates
    socketRef.current = io(API_URL, SOCKET_OPTIONS);
    
    socketRef.current.on('connect', () => {
      console.log('Stats: Socket.IO connected successfully');
      setConnected(true);
      setError(null);
    });
    
    socketRef.current.on('connect_error', (error) => {
      console.error('Stats: Socket.IO connection error:', error);
      setConnected(false);
      setError("Connection error. Real-time updates paused.");
    });
    
    // Listen for alert updates and update the total alerts count
    socketRef.current.on('alertUpdate', (alert) => {
      if (Array.isArray(alert)) {
        setStats(prev => ({ ...prev, totalAlerts: alert.length }));
      } else {
        setStats(prev => ({ ...prev, totalAlerts: prev.totalAlerts + 1 }));
      }
    });
    
    // Listen for anomaly score updates to recalculate the average
    socketRef.current.on('update', (anomalyData) => {
      if (Array.isArray(anomalyData) && anomalyData.length > 0) {
        // Calculate new average including the latest score
        const latestScore = anomalyData[0].score;
        setStats(prev => {
          // Simple moving average calculation
          return { 
            ...prev,
            avgAnomalyScore: Number((prev.avgAnomalyScore * 0.9 + latestScore * 0.1).toFixed(3))
          };
        });
      }
    });
    
    // Listen for stats updates from the server
    socketRef.current.on('statsUpdate', (newStats) => {
      setStats(newStats);
    });
    
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, []);

  // Format the average anomaly score to 3 decimal places
  const formattedAvgScore = stats.avgAnomalyScore?.toFixed(3) || '0.000';

  // Determine severity level for visual indicators
  const getSeverityLevel = (score) => {
    if (score >= 0.7) return { level: 'Critical', color: 'error' };
    if (score >= 0.4) return { level: 'Elevated', color: 'warning' };
    return { level: 'Normal', color: 'success' };
  };

  const severityInfo = getSeverityLevel(stats.avgAnomalyScore);

  return (
    <Paper sx={{ p: 2, mb: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Stats Summary</Typography>
        {connected ? (
          <Chip label="Connected" color="success" size="small" />
        ) : (
          <Chip label="Disconnected" color="error" size="small" />
        )}
      </Box>
      
      {error && (
        <Typography color="error" variant="body2" sx={{ mb: 2 }}>
          {error}
        </Typography>
      )}
      
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <Box sx={{ p: 2, borderRadius: 1, bgcolor: 'background.paper', boxShadow: 1 }}>
            <Typography variant="h6" gutterBottom>Total Alerts</Typography>
            <Typography variant="h3" sx={{ fontWeight: 'bold' }}>
              {stats.totalAlerts}
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={6}>
          <Box sx={{ 
            p: 2, 
            borderRadius: 1, 
            bgcolor: 'background.paper', 
            boxShadow: 1,
            borderLeft: 3,
            borderColor: `${severityInfo.color}.main`
          }}>
            <Typography variant="h6" gutterBottom>Avg. Anomaly Score</Typography>
            <Typography variant="h3" sx={{ fontWeight: 'bold' }}>
              {formattedAvgScore}
            </Typography>
            <Chip 
              label={severityInfo.level} 
              color={severityInfo.color} 
              size="small" 
              sx={{ mt: 1 }}
            />
          </Box>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default StatsSummary;
