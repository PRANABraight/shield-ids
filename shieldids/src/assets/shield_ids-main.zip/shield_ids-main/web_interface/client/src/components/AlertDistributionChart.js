// web_interface/client/src/components/AlertDistributionChart.js
import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, PieChart, Pie, Tooltip, Legend, Cell } from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AA336A'];

const AlertDistributionChart = () => {
  const [distributionData, setDistributionData] = useState([]);

  useEffect(() => {
    const fetchDistribution = async () => {
      try {
        const response = await fetch("http://localhost:5050/api/alertDistribution");
        const data = await response.json();
        // Data format: [{ type: 'SQL Injection', count: 10 }, { type: 'RFI', count: 5 }, ...]
        setDistributionData(data);
      } catch (error) {
        console.error("Error fetching alert distribution:", error);
      }
    };

    const interval = setInterval(fetchDistribution, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie 
          data={distributionData} 
          dataKey="count" 
          nameKey="type" 
          cx="50%" 
          cy="50%" 
          outerRadius={80} 
          fill="#8884d8"
          label
        >
          {distributionData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
};

export default AlertDistributionChart;
