// src/App.js
import React, { useEffect, lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Container, CssBaseline, Box, createTheme, ThemeProvider, CircularProgress, Typography } from '@mui/material';
import Sidebar from './components/Sidebar';
import AlertTable from './components/AlertTable';
import TrafficVolumeChart from './components/TrafficVolumeChart';
import AlertDistributionChart from './components/AlertDistributionChart';
import CorrelationScatterPlot from './components/CorrelationScatterPlot';
import AlertsHeatmap from './components/AlertsHeatmap';
import StatsSummary from './components/StatsSummary';
import AnomalyHistoryChart from './components/AnomalyHistoryChart';
import MetricCards from './components/MetricCards';
import RealTimeAttackFeed from './components/RealTimeAttackFeed';

// Create a dark theme for the security dashboard
const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#90caf9',
    },
    secondary: {
      main: '#f48fb1',
    },
    background: {
      default: '#121212',
      paper: '#1e1e1e',
    },
    error: {
      main: '#f44336',
    },
    warning: {
      main: '#ff9800',
    },
    info: {
      main: '#29b6f6',
    },
    success: {
      main: '#66bb6a',
    },
  },
});

// Error boundary for graceful error handling
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("UI Error:", error, errorInfo);
    // Here you could send the error to an error reporting service
  }

  render() {
    if (this.state.hasError) {
      return (
        <Box sx={{ p: 3, textAlign: 'center' }}>
          <Typography variant="h5" color="error" gutterBottom>
            Something went wrong
          </Typography>
          <Typography variant="body1" gutterBottom>
            We apologize for the inconvenience. Please try refreshing the page.
          </Typography>
          <Box sx={{ mt: 2 }}>
            <button 
              onClick={() => window.location.reload()} 
              style={{ 
                padding: '8px 16px', 
                background: darkTheme.palette.primary.main,
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Refresh Page
            </button>
          </Box>
        </Box>
      );
    }

    return this.props.children;
  }
}

// Loading component for suspense fallback
const Loading = () => (
  <Box 
    sx={{ 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center', 
      minHeight: '100vh'
    }}
  >
    <CircularProgress />
  </Box>
);

// Dashboard aggregates the components that are always visible
const Dashboard = () => {
  // Performance monitoring
  useEffect(() => {
    const start = performance.now();
    
    return () => {
      const end = performance.now();
      const loadTime = end - start;
      console.log(`Dashboard loaded in: ${loadTime.toFixed(2)}ms`);
      
      // Report if dashboard loads slowly
      if (loadTime > 1000) {
        console.warn('Dashboard loaded slowly. Consider further optimization.');
      }
    };
  }, []);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, py: 2 }}>
      <MetricCards />
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '2fr 1fr' }, gap: 3 }}>
        <TrafficVolumeChart />
        <RealTimeAttackFeed />
      </Box>
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 3 }}>
        <AlertDistributionChart />
        <CorrelationScatterPlot />
      </Box>
      <AlertsHeatmap />
    </Box>
  );
};

function App() {
  // Monitor for memory leaks
  useEffect(() => {
    // Check for memory usage every 30 seconds
    const memoryInterval = setInterval(() => {
      if (window.performance && window.performance.memory) {
        const { usedJSHeapSize, jsHeapSizeLimit } = window.performance.memory;
        const usedPercent = (usedJSHeapSize / jsHeapSizeLimit) * 100;
        
        if (usedPercent > 80) {
          console.warn(`High memory usage: ${usedPercent.toFixed(1)}% of available heap`);
        }
      }
    }, 30000);
    
    return () => clearInterval(memoryInterval);
  }, []);

  return (
    <ThemeProvider theme={darkTheme}>
      <ErrorBoundary>
        <Router>
          <CssBaseline />
          <Sidebar />
          <Container style={{ marginLeft: '240px', padding: '20px' }}>
            <Suspense fallback={<Loading />}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/alerts" element={<AlertTable />} />
                <Route path="/stats" element={<StatsSummary />} />
                <Route path="/anomaly-history" element={<AnomalyHistoryChart />} />
              </Routes>
            </Suspense>
          </Container>
        </Router>
      </ErrorBoundary>
    </ThemeProvider>
  );
}

export default App;
