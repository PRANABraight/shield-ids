import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Box, Paper, Typography, CircularProgress, Alert, Chip } from '@mui/material';
import { io } from 'socket.io-client';
import AnomalyHistoryChart from './AnomalyHistoryChart';
import TimelineIcon from '@mui/icons-material/Timeline';
import { measureRenderTime, debounce, optimizeChartData, performanceConfig } from '../utils/performance';
import { API_URL, SOCKET_OPTIONS, getAnomalyScores } from '../api';

const MAX_HISTORY_POINTS = 50; // Maximum number of data points to show in the chart

const RealTimeScores = () => {
  const [scoreHistory, setScoreHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [connected, setConnected] = useState(false);
  const socketRef = useRef(null);
  const updateTimeoutRef = useRef(null);
  
  // Get current anomaly score (most recent)
  const currentScore = useMemo(() => {
    if (scoreHistory.length === 0) return { score: 0, time: 'N/A' };
    return scoreHistory[scoreHistory.length - 1];
  }, [scoreHistory]);
  
  // Determine threat level based on score
  const getThreatLevel = (score) => {
    if (score >= 0.7) return { level: 'critical', color: 'error' };
    if (score >= 0.4) return { level: 'elevated', color: 'warning' };
    return { level: 'normal', color: 'success' };
  };
  
  // Get current threat level
  const currentThreat = useMemo(() => 
    getThreatLevel(currentScore.score), [currentScore.score]);
  
  // Start performance measurement
  const [startMeasure, endMeasure] = measureRenderTime('RealTimeScores');

  // Debounced score update to prevent too frequent UI updates
  const handleScoreUpdate = useMemo(() => debounce((newEntries) => {
    if (!Array.isArray(newEntries) || newEntries.length === 0) return;
    
    setScoreHistory(prev => {
      // Combine with existing scores and limit size
      const combined = [...prev, ...newEntries];
      return optimizeChartData(combined, MAX_HISTORY_POINTS);
    });
  }, performanceConfig.INPUT_DEBOUNCE), []);

  useEffect(() => {
    startMeasure();
    
    // Initial data fetch
    const fetchInitialData = async () => {
      setLoading(true);
      try {
        const data = await getAnomalyScores();
        
        // Apply optimization to limit data points
        const optimizedData = optimizeChartData(data, MAX_HISTORY_POINTS);
        setScoreHistory(optimizedData);
        setError(null);
      } catch (error) {
        console.error("Error fetching anomaly scores:", error);
        setError("Failed to load initial anomaly scores");
      } finally {
        setLoading(false);
      }
    };

    fetchInitialData();

    // Set up Socket.IO connection with better configuration
    socketRef.current = io(API_URL, SOCKET_OPTIONS);

    // Handle connection status
    socketRef.current.on('connect', () => {
      console.log('Connected to Socket.IO server');
      setConnected(true);
      setError(null);
    });

    socketRef.current.on('connect_error', (err) => {
      console.error('Socket.IO connection error:', err);
      setConnected(false);
      setError('Connection error. Real-time updates paused.');
    });

    socketRef.current.on('reconnect', (attemptNumber) => {
      console.log(`Reconnected to Socket.IO server after ${attemptNumber} attempts`);
      setConnected(true);
      setError(null);
    });

    // Listen for "update" events which send anomaly score data
    socketRef.current.on("update", (newEntries) => {
      handleScoreUpdate(newEntries);
    });

    return () => {
      endMeasure();
      
      // Clean up socket connection
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
      
      // Clear any pending timeouts
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
    };
  }, [handleScoreUpdate, endMeasure, startMeasure]);

  return (
    <Paper sx={{ p: 2, mb: 3, position: 'relative' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <TimelineIcon color="primary" sx={{ mr: 1 }} />
        <Typography variant="h6" component="h2" sx={{ flexGrow: 1 }}>
          Real-Time Anomaly Detection
        </Typography>
        
        {/* Connection status indicator */}
        <Chip 
          label={connected ? "Connected" : "Disconnected"} 
          color={connected ? "success" : "error"}
          size="small"
          sx={{ ml: 1 }}
        />
      </Box>
      
      {/* Error alert */}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      
      {/* Main content */}
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Box>
          {/* Current score display */}
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 2,
            p: 2,
            borderRadius: 1,
            bgcolor: `${currentThreat.color}.light`
          }}>
            <Box>
              <Typography variant="subtitle2" color="text.secondary">
                Current Threat Level
              </Typography>
              <Typography 
                variant="h5" 
                color={`${currentThreat.color}.main`}
                sx={{ fontWeight: 'bold', textTransform: 'capitalize' }}
              >
                {currentThreat.level}
              </Typography>
            </Box>
            
            <Box sx={{ textAlign: 'right' }}>
              <Typography variant="subtitle2" color="text.secondary">
                Anomaly Score
              </Typography>
              <Typography 
                variant="h5" 
                color={`${currentThreat.color}.main`}
                sx={{ fontWeight: 'bold' }}
              >
                {currentScore.score.toFixed(3)}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Last updated: {currentScore.time}
              </Typography>
            </Box>
          </Box>
          
          {/* Anomaly history chart */}
          <AnomalyHistoryChart data={scoreHistory} />
        </Box>
      )}
    </Paper>
  );
};

export default RealTimeScores;
