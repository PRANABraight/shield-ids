// src/components/AlertTable.js
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { 
  Paper, 
  Table, 
  TableHead, 
  TableRow, 
  TableCell, 
  TableBody, 
  Typography, 
  Box,
  Chip,
  IconButton,
  Collapse,
  TableContainer,
  TablePagination,
  TextField,
  InputAdornment,
  CircularProgress
} from '@mui/material';
import { io } from 'socket.io-client';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import WarningIcon from '@mui/icons-material/Warning';
import ErrorIcon from '@mui/icons-material/Error';
import InfoIcon from '@mui/icons-material/Info';
import { debounce, optimizeChartData } from '../utils/performance';
import { API_URL, SOCKET_OPTIONS, getAlerts } from '../api';

// Memoized Alert Row component to improve performance
const AlertRow = React.memo(({ alert, onToggleExpand, isExpanded }) => {
  // Choose icon based on severity
  const getAlertIcon = (alert) => {
    const severity = alert.severity || 0;
    
    if (severity >= 2) return <ErrorIcon sx={{ color: 'error.main' }} />;
    if (severity >= 1) return <WarningIcon sx={{ color: 'warning.main' }} />;
    return <InfoIcon sx={{ color: 'info.main' }} />;
  };
  
  // Format timestamp
  const formatTime = (timestamp) => {
    if (!timestamp) return 'N/A';
    try {
      return new Date(timestamp).toLocaleTimeString();
    } catch (e) {
      return timestamp;
    }
  };
  
  // Get severity color
  const getSeverityColor = (severity) => {
    if (severity >= 2) return 'error';
    if (severity >= 1) return 'warning';
    return 'info';
  };
  
  return (
    <>
      <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
        <TableCell>
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={() => onToggleExpand(alert.id)}
          >
            {isExpanded ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell>
          {getAlertIcon(alert)}
        </TableCell>
        <TableCell>{formatTime(alert.timestamp || alert.time)}</TableCell>
        <TableCell>{alert.src_ip || 'Unknown'}</TableCell>
        <TableCell>{alert.dest_ip || 'Unknown'}</TableCell>
        <TableCell>{alert.proto || 'Unknown'}</TableCell>
        <TableCell>
          <Chip 
            label={alert.msg || 'Unknown Alert'} 
            color={getSeverityColor(alert.severity)} 
            size="small"
            variant="outlined"
          />
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={7}>
          <Collapse in={isExpanded} timeout="auto" unmountOnExit>
            <Box sx={{ margin: 1 }}>
              <Typography variant="h6" gutterBottom component="div">
                Alert Details
              </Typography>
              <Table size="small" aria-label="alert details">
                <TableHead>
                  <TableRow>
                    <TableCell>Property</TableCell>
                    <TableCell>Value</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell component="th" scope="row">Signature</TableCell>
                    <TableCell>{alert.msg || 'N/A'}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" scope="row">Signature ID</TableCell>
                    <TableCell>{alert.signature_id || 'N/A'}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" scope="row">Category</TableCell>
                    <TableCell>{alert.category || 'N/A'}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" scope="row">Severity</TableCell>
                    <TableCell>{alert.severity || 'N/A'}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" scope="row">Action</TableCell>
                    <TableCell>{alert.action || 'N/A'}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" scope="row">Timestamp</TableCell>
                    <TableCell>{alert.timestamp || 'N/A'}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </>
  );
});

const AlertTable = () => {
  const [alerts, setAlerts] = useState([]);
  const [filteredAlerts, setFilteredAlerts] = useState([]);
  const [expandedId, setExpandedId] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const socketRef = useRef(null);
  
  // Handler for toggling expanded rows
  const handleToggleExpand = useCallback((id) => {
    setExpandedId(prevId => (prevId === id ? null : id));
  }, []);
  
  // Process alerts by adding unique IDs if they don't have one
  const processAlertsWithIds = useCallback((alertsData) => {
    return alertsData.map(alert => ({
      ...alert,
      id: alert.id || `alert-${alert.timestamp || alert.time || Date.now()}-${Math.random().toString(36).substring(2, 9)}`
    }));
  }, []);

  useEffect(() => {
    // Debounced search function to prevent excessive filtering
    const debouncedSearch = debounce((term, alertsToFilter) => {
      if (!term.trim()) {
        setFilteredAlerts(alertsToFilter);
        return;
      }

      const lowerTerm = term.toLowerCase();
      const filtered = alertsToFilter.filter(alert => {
        return (
          (alert.msg && alert.msg.toLowerCase().includes(lowerTerm)) ||
          (alert.src_ip && alert.src_ip.includes(term)) ||
          (alert.dest_ip && alert.dest_ip.includes(term)) ||
          (alert.proto && alert.proto.toLowerCase().includes(lowerTerm))
        );
      });

      setFilteredAlerts(filtered);
    }, 300);

    // Initial fetch
    const fetchAlerts = async () => {
      setLoading(true);
      try {
        const data = await getAlerts();
        const processedAlerts = processAlertsWithIds(data);
        // Optimize for large datasets
        const optimizedAlerts = optimizeChartData(processedAlerts, 500);
        setAlerts(optimizedAlerts);
        debouncedSearch(searchTerm, optimizedAlerts);
        setError(null);
      } catch (error) {
        console.error("Error fetching alerts:", error);
        setError("Failed to load alerts. Please check your network connection.");
      } finally {
        setLoading(false);
      }
    };

    fetchAlerts();

    // Set up Socket.IO for real-time updates with optimized settings
    socketRef.current = io(API_URL, SOCKET_OPTIONS);
    
    const handleAlertUpdate = (newAlert) => {
      if (Array.isArray(newAlert)) {
        // If we get a full array of alerts, process them all
        const processedAlerts = processAlertsWithIds(newAlert);
        // Optimize for large datasets
        const optimizedAlerts = optimizeChartData(processedAlerts, 500);
        setAlerts(optimizedAlerts);
        debouncedSearch(searchTerm, optimizedAlerts);
      } else {
        // For a single alert update
        const processedAlert = { 
          ...newAlert, 
          id: newAlert.id || `alert-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
        };
        
        setAlerts(prev => {
          const updatedAlerts = [processedAlert, ...prev];
          // Limit the number of alerts in memory to prevent performance issues
          const optimizedAlerts = optimizeChartData(updatedAlerts, 500);
          debouncedSearch(searchTerm, optimizedAlerts);
          return optimizedAlerts;
        });
      }
    };
    
    // Listen for error events
    socketRef.current.on("connect_error", (err) => {
      console.error("Socket connection error:", err);
      setError("Connection error. Real-time updates paused.");
    });
    
    socketRef.current.on("reconnect", () => {
      setError(null);
      console.log("Reconnected to server");
    });

    // Listen for alert updates
    socketRef.current.on("alertUpdate", handleAlertUpdate);

    return () => {
      if (socketRef.current) {
        socketRef.current.off("alertUpdate", handleAlertUpdate);
        socketRef.current.disconnect();
      }
    };
  }, [searchTerm, processAlertsWithIds]);

  // Handle search input changes
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
    setPage(0); // Reset to first page when searching
  };

  // Handle pagination changes
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Calculate paginated data
  const paginatedData = useMemo(() => {
    return filteredAlerts.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
  }, [filteredAlerts, page, rowsPerPage]);

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden', mb: 3 }}>
      <Box sx={{ p: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="h6">Security Alerts</Typography>
        
        <TextField
          placeholder="Search alerts..."
          size="small"
          value={searchTerm}
          onChange={handleSearchChange}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                <IconButton size="small">
                  <FilterListIcon />
                </IconButton>
              </InputAdornment>
            ),
          }}
          sx={{ width: 300 }}
        />
      </Box>
      
      {error && (
        <Box sx={{ p: 2 }}>
          <Typography color="error">{error}</Typography>
        </Box>
      )}
      
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          <TableContainer sx={{ maxHeight: 440 }}>
            <Table stickyHeader aria-label="security alerts table">
              <TableHead>
                <TableRow>
                  <TableCell style={{ width: '5%' }} />
                  <TableCell style={{ width: '5%' }}>Severity</TableCell>
                  <TableCell style={{ width: '15%' }}>Time</TableCell>
                  <TableCell style={{ width: '15%' }}>Source</TableCell>
                  <TableCell style={{ width: '15%' }}>Destination</TableCell>
                  <TableCell style={{ width: '10%' }}>Protocol</TableCell>
                  <TableCell style={{ width: '35%' }}>Description</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedData.length > 0 ? (
                  paginatedData.map((alert) => (
                    <AlertRow
                      key={alert.id}
                      alert={alert}
                      onToggleExpand={handleToggleExpand}
                      isExpanded={expandedId === alert.id}
                    />
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      {searchTerm ? 'No matching alerts found' : 'No alerts available'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={filteredAlerts.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </>
      )}
    </Paper>
  );
};

export default AlertTable;
