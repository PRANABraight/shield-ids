// src/components/CorrelationScatterPlot.js
import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Paper, Typography } from '@mui/material';

const CorrelationScatterPlot = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchCorrelationData = async () => {
      try {
        const response = await fetch("http://localhost:5050/api/correlation");
        const correlationData = await response.json();
        // Expected format: [{ trafficVolume: <number>, anomalyScore: <number>, time: <string> }, ...]
        setData(correlationData);
      } catch (error) {
        console.error("Error fetching correlation data:", error);
      }
    };

    // Fetch correlation data every 5 seconds
    fetchCorrelationData();
    const interval = setInterval(fetchCorrelationData, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Paper style={{ padding: '16px', marginTop: '20px' }}>
      <Typography variant="h6">Correlation: Traffic Volume vs. Anomaly Score</Typography>
      <ResponsiveContainer width="100%" height={300}>
        <ScatterChart>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="trafficVolume" name="Traffic Volume" />
          <YAxis dataKey="anomalyScore" name="Anomaly Score" />
          <Tooltip cursor={{ strokeDasharray: '3 3' }} />
          <Legend />
          <Scatter name="Correlation Data" data={data} fill="#8884d8" />
        </ScatterChart>
      </ResponsiveContainer>
    </Paper>
  );
};

export default CorrelationScatterPlot;
