// src/components/Sidebar.js
import React from 'react';
import { 
  Drawer, 
  List, 
  ListItem, 
  ListItemIcon, 
  ListItemText, 
  Divider, 
  Box, 
  Typography 
} from '@mui/material';
import { Link, useLocation } from 'react-router-dom';
import DashboardIcon from '@mui/icons-material/Dashboard';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import AssessmentIcon from '@mui/icons-material/Assessment';
import TimelineIcon from '@mui/icons-material/Timeline';
import ShieldIcon from '@mui/icons-material/Shield';

const Sidebar = () => {
  const location = useLocation();
  
  const isActive = (path) => {
    return location.pathname === path;
  };
  
  return (
    <Drawer 
      variant="permanent" 
      anchor="left"
      sx={{
        width: 240,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: 240,
          boxSizing: 'border-box',
          bgcolor: 'background.paper',
          borderRight: 1,
          borderColor: 'divider'
        },
      }}
    >
      <Box sx={{ 
        display: 'flex', 
        flexDirection: 'column', 
        alignItems: 'center', 
        py: 3,
        mb: 2
      }}>
        <ShieldIcon sx={{ fontSize: 48, color: 'primary.main', mb: 1 }} />
        <Typography variant="h5" component="h1" sx={{ fontWeight: 'bold', mb: 0.5 }}>
          SHIELD IDS
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Real-time Network Security
        </Typography>
      </Box>
      
      <Divider />
      
      <List sx={{ px: 1 }}>
        <ListItem 
          button 
          component={Link} 
          to="/"
          sx={{ 
            borderRadius: 1,
            mb: 0.5,
            bgcolor: isActive('/') ? 'action.selected' : 'transparent',
            '&:hover': {
              bgcolor: 'action.hover'
            }
          }}
        >
          <ListItemIcon>
            <DashboardIcon color={isActive('/') ? 'primary' : 'inherit'} />
          </ListItemIcon>
          <ListItemText 
            primary="Dashboard" 
            primaryTypographyProps={{ 
              fontWeight: isActive('/') ? 'bold' : 'normal' 
            }}
          />
        </ListItem>
        
        <ListItem 
          button 
          component={Link} 
          to="/alerts"
          sx={{ 
            borderRadius: 1,
            mb: 0.5,
            bgcolor: isActive('/alerts') ? 'action.selected' : 'transparent',
            '&:hover': {
              bgcolor: 'action.hover'
            }
          }}
        >
          <ListItemIcon>
            <WarningAmberIcon color={isActive('/alerts') ? 'primary' : 'inherit'} />
          </ListItemIcon>
          <ListItemText 
            primary="Alerts" 
            primaryTypographyProps={{ 
              fontWeight: isActive('/alerts') ? 'bold' : 'normal' 
            }}
          />
        </ListItem>
        
        <ListItem 
          button 
          component={Link} 
          to="/stats"
          sx={{ 
            borderRadius: 1,
            mb: 0.5,
            bgcolor: isActive('/stats') ? 'action.selected' : 'transparent',
            '&:hover': {
              bgcolor: 'action.hover'
            }
          }}
        >
          <ListItemIcon>
            <AssessmentIcon color={isActive('/stats') ? 'primary' : 'inherit'} />
          </ListItemIcon>
          <ListItemText 
            primary="Statistics" 
            primaryTypographyProps={{ 
              fontWeight: isActive('/stats') ? 'bold' : 'normal' 
            }}
          />
        </ListItem>
        
        <ListItem 
          button 
          component={Link} 
          to="/anomaly-history"
          sx={{ 
            borderRadius: 1,
            bgcolor: isActive('/anomaly-history') ? 'action.selected' : 'transparent',
            '&:hover': {
              bgcolor: 'action.hover'
            }
          }}
        >
          <ListItemIcon>
            <TimelineIcon color={isActive('/anomaly-history') ? 'primary' : 'inherit'} />
          </ListItemIcon>
          <ListItemText 
            primary="Anomaly History" 
            primaryTypographyProps={{ 
              fontWeight: isActive('/anomaly-history') ? 'bold' : 'normal' 
            }}
          />
        </ListItem>
      </List>
      
      <Box sx={{ flexGrow: 1 }} />
      
      <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', textAlign: 'center' }}>
          © SHIELD IDS {new Date().getFullYear()}
        </Typography>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', textAlign: 'center' }}>
          Protecting Networks in Real-Time
        </Typography>
      </Box>
    </Drawer>
  );
};

export default Sidebar;
