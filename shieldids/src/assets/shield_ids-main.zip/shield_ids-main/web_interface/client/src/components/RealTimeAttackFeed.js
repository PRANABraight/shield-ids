import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Box, Paper, Typography, List, ListItem, ListItemText, Collapse, Chip } from '@mui/material';
import { io } from 'socket.io-client';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import WarningIcon from '@mui/icons-material/Warning';
import ErrorIcon from '@mui/icons-material/Error';
import InfoIcon from '@mui/icons-material/Info';
import { API_URL, SOCKET_OPTIONS } from '../api';

// Extract Alert Item to its own memoized component to prevent unnecessary re-renders
const AlertItem = React.memo(({ alert, alertId, isExpanded, toggleExpand }) => {
  // Determine severity level based on alert properties
  const getSeverity = (alert) => {
    const msg = alert.msg?.toLowerCase() || '';
    if (msg.includes('critical') || msg.includes('high') || msg.includes('attack')) {
      return 'critical';
    } else if (msg.includes('warning') || msg.includes('suspicious')) {
      return 'warning';
    }
    return 'info';
  };

  // Get appropriate icon based on severity
  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical':
        return <ErrorIcon sx={{ color: 'error.main' }} />;
      case 'warning':
        return <WarningIcon sx={{ color: 'warning.main' }} />;
      default:
        return <InfoIcon sx={{ color: 'info.main' }} />;
    }
  };

  // Get color for the severity chip
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical':
        return 'error';
      case 'warning':
        return 'warning';
      default:
        return 'info';
    }
  };

  // Format timestamp
  const formatTime = (timestamp) => {
    if (!timestamp) return 'N/A';
    try {
      return new Date(timestamp).toLocaleTimeString();
    } catch (e) {
      return timestamp;
    }
  };

  const severity = getSeverity(alert);

  return (
    <ListItem 
      key={alertId}
      sx={{ 
        mb: 1, 
        flexDirection: 'column', 
        alignItems: 'flex-start',
        bgcolor: 'background.paper',
        borderLeft: 3,
        borderColor: `${getSeverityColor(severity)}.main`,
        borderRadius: 1,
        '&:hover': {
          bgcolor: 'action.hover'
        },
        className: severity === 'critical' ? 'blink' : ''
      }}
    >
      <Box 
        sx={{ 
          display: 'flex', 
          width: '100%',
          alignItems: 'center', 
          justifyContent: 'space-between',
          cursor: 'pointer'
        }}
        onClick={() => toggleExpand(alertId)}
      >
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          {getSeverityIcon(severity)}
          <Typography variant="body1" sx={{ ml: 1, fontWeight: 'bold' }}>
            {alert.msg || 'Unknown Alert'}
          </Typography>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Chip 
            size="small" 
            label={severity.toUpperCase()} 
            color={getSeverityColor(severity)} 
            sx={{ mr: 1 }}
          />
          <Typography variant="body2" color="text.secondary">
            {formatTime(alert.timestamp)}
          </Typography>
          {isExpanded ? <ExpandLessIcon /> : <ExpandMoreIcon />}
        </Box>
      </Box>
      
      <Collapse in={isExpanded} timeout="auto" sx={{ width: '100%' }}>
        <Box sx={{ p: 2, mt: 1 }}>
          <Typography variant="body2">
            <strong>Source IP:</strong> {alert.src_ip || 'N/A'}
          </Typography>
          <Typography variant="body2">
            <strong>Destination IP:</strong> {alert.dest_ip || 'N/A'}
          </Typography>
          <Typography variant="body2">
            <strong>Protocol:</strong> {alert.proto || 'N/A'}
          </Typography>
          {alert.payload && (
            <Typography variant="body2" sx={{ wordBreak: 'break-all' }}>
              <strong>Payload:</strong> {alert.payload}
            </Typography>
          )}
          {alert.category && (
            <Typography variant="body2">
              <strong>Category:</strong> {alert.category}
            </Typography>
          )}
        </Box>
      </Collapse>
    </ListItem>
  );
});

const RealTimeAttackFeed = () => {
  const [alerts, setAlerts] = useState([]);
  const [expandedAlerts, setExpandedAlerts] = useState({});
  const alertsContainerRef = useRef(null);
  const socketRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState(null);

  // Toggle expanded state for an alert - memoized to prevent re-renders
  const toggleExpand = useCallback((id) => {
    setExpandedAlerts(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  }, []);

  useEffect(() => {
    // Initial fetch of alerts
    const fetchAlerts = async () => {
      try {
        const response = await fetch(`${API_URL}/api/alerts`);
        if (!response.ok) throw new Error('Failed to fetch alerts');
        const data = await response.json();
        // Only keep the most recent 10 alerts to begin with
        const recentAlerts = data.slice(0, 10);
        setAlerts(recentAlerts);
      } catch (error) {
        console.error("Error fetching alerts:", error);
        setError("Failed to load alerts. Please check your connection.");
      }
    };
    
    fetchAlerts();
    
    // Set up Socket.IO connection for real-time updates
    socketRef.current = io(API_URL, SOCKET_OPTIONS);
    
    console.log('Connecting to Socket.IO server at:', API_URL);
    
    socketRef.current.on('connect', () => {
      console.log('Socket.IO connected successfully');
      setConnected(true);
      setError(null);
    });
    
    socketRef.current.on('connect_error', (error) => {
      console.error('Socket.IO connection error:', error);
      setConnected(false);
      setError("Connection error. Real-time updates paused.");
    });

    socketRef.current.on('reconnect', () => {
      console.log('Socket.IO reconnected');
      setConnected(true);
      setError(null);
    });
    
    const handleAlertUpdate = (alert) => {
      if (Array.isArray(alert)) {
        // If we get a full array of alerts, just take the most recent 10
        setAlerts(prev => [...alert.slice(0, 10)]);
      } else {
        // For a single alert update, add it to the top
        setAlerts(prev => {
          const newAlerts = [alert, ...prev];
          // Keep the list limited to 10 items
          return newAlerts.slice(0, 10);
        });
        
        // Auto-scroll to the top when new alerts come in
        if (alertsContainerRef.current) {
          alertsContainerRef.current.scrollTop = 0;
        }
      }
    };
    
    // Listen for new alerts
    socketRef.current.on("alertUpdate", handleAlertUpdate);
    
    return () => {
      // Clean up
      if (socketRef.current) {
        socketRef.current.off("alertUpdate", handleAlertUpdate);
        socketRef.current.disconnect();
      }
    };
  }, []);

  return (
    <Paper 
      elevation={3} 
      sx={{ 
        p: 2,
        height: '100%',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <Typography variant="h6" component="h2" sx={{ mb: 1 }}>
        Real-Time Attack Feed
        {connected ? (
          <Chip 
            label="Connected" 
            color="success" 
            size="small" 
            sx={{ ml: 2 }} 
          />
        ) : (
          <Chip 
            label="Disconnected" 
            color="error" 
            size="small" 
            sx={{ ml: 2 }} 
          />
        )}
      </Typography>
      
      {error && (
        <Typography color="error" variant="body2" sx={{ mb: 2 }}>
          {error}
        </Typography>
      )}
      
      <Box 
        ref={alertsContainerRef}
        sx={{ 
          flexGrow: 1, 
          overflowY: 'auto',
          maxHeight: '400px'
        }}
      >
        <List>
          {alerts.length === 0 ? (
            <ListItem>
              <ListItemText primary="No alerts detected yet" />
            </ListItem>
          ) : (
            alerts.map((alert, index) => {
              const alertId = alert.id || `alert-${index}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
              const isExpanded = expandedAlerts[alertId] || false;
              
              return (
                <AlertItem 
                  key={alertId}
                  alert={alert} 
                  alertId={alertId} 
                  isExpanded={isExpanded}
                  toggleExpand={toggleExpand}
                />
              );
            })
          )}
        </List>
      </Box>
    </Paper>
  );
};

export default RealTimeAttackFeed; 