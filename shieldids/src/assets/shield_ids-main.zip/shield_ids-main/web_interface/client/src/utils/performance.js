/**
 * Performance monitoring and optimization utilities for the IDS dashboard
 */

// Debug flag - set to true to enable performance logging
const DEBUG_PERFORMANCE = process.env.NODE_ENV === 'development';

/**
 * Measures and logs component render time
 * @param {string} componentName - Name of the component being measured
 * @param {function} callback - Optional callback for custom handling of timing data
 * @returns {Array} - start and end functions for measuring
 */
export const measureRenderTime = (componentName, callback) => {
  let startTime;

  const start = () => {
    startTime = performance.now();
  };

  const end = () => {
    const endTime = performance.now();
    const duration = endTime - startTime;
    
    if (DEBUG_PERFORMANCE) {
      console.log(`⏱️ ${componentName} render time: ${duration.toFixed(2)}ms`);
      
      if (duration > 100) {
        console.warn(`⚠️ Slow render detected in ${componentName}: ${duration.toFixed(2)}ms`);
      }
    }
    
    if (callback && typeof callback === 'function') {
      callback(duration);
    }
    
    return duration;
  };

  return [start, end];
};

/**
 * Creates a debounced version of a function
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} - Debounced function
 */
export const debounce = (func, wait) => {
  let timeout;
  
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

/**
 * Throttles a function to limit how often it can be called
 * @param {Function} func - Function to throttle
 * @param {number} limit - Time limit in milliseconds
 * @returns {Function} - Throttled function
 */
export const throttle = (func, limit) => {
  let inThrottle;
  
  return function(...args) {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
};

/**
 * Checks browser memory usage
 * @returns {Object|null} - Memory usage stats or null if not available
 */
export const checkMemoryUsage = () => {
  if (window.performance && window.performance.memory) {
    const { usedJSHeapSize, jsHeapSizeLimit, totalJSHeapSize } = window.performance.memory;
    const usedPercent = (usedJSHeapSize / jsHeapSizeLimit) * 100;
    
    const result = {
      used: formatBytes(usedJSHeapSize),
      total: formatBytes(jsHeapSizeLimit),
      allocated: formatBytes(totalJSHeapSize),
      percentUsed: usedPercent.toFixed(1)
    };
    
    if (DEBUG_PERFORMANCE && usedPercent > 70) {
      console.warn(`🔥 High memory usage: ${usedPercent.toFixed(1)}% of available JS heap`);
    }
    
    return result;
  }
  
  return null;
};

/**
 * Format bytes to human-readable format
 * @param {number} bytes - Bytes to format
 * @returns {string} - Formatted string
 */
export const formatBytes = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

/**
 * Optimizes data array length for charts
 * @param {Array} data - Data array
 * @param {number} maxPoints - Maximum data points to keep
 * @returns {Array} - Optimized array
 */
export const optimizeChartData = (data = [], maxPoints = 100) => {
  if (!Array.isArray(data)) return [];
  if (data.length <= maxPoints) return data;
  
  // For large datasets, keep latest maxPoints items
  return data.slice(-maxPoints);
};

// Export default configuration
export const performanceConfig = {
  // Maximum number of data points to show in charts
  MAX_CHART_POINTS: 50,
  
  // Debounce time for input handlers (ms)
  INPUT_DEBOUNCE: 150,
  
  // Throttle time for scroll handlers (ms)
  SCROLL_THROTTLE: 100,
  
  // Memory check interval (ms)
  MEMORY_CHECK_INTERVAL: 30000
}; 