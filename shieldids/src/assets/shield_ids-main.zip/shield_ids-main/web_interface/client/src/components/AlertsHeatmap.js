import React, { useState, useEffect } from 'react';
import { Paper, Typography } from '@mui/material';

const AlertsHeatmap = () => {
  const [heatmapData, setHeatmapData] = useState([]);

  useEffect(() => {
    const fetchHeatmapData = async () => {
      try {
        const response = await fetch("http://localhost:5050/api/alertHeatmap");
        const data = await response.json();
        // Expect data to be a 2D array, e.g., rows represent time intervals, columns represent network segments.
        setHeatmapData(data);
      } catch (error) {
        console.error("Error fetching heatmap data:", error);
      }
    };

    const interval = setInterval(fetchHeatmapData, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Paper style={{ padding: '16px', marginTop: '20px' }}>
      <Typography variant="h6">Alerts Heatmap</Typography>
      <div style={{
        display: 'grid', 
        gridTemplateColumns: `repeat(${heatmapData[0]?.length || 1}, 40px)`,
        gap: '2px'
      }}>
        {heatmapData.flat().map((value, index) => {
          // Use the value to determine the background color intensity
          const intensity = Math.min(255, value * 50);
          return (
            <div 
              key={index} 
              style={{
                width: '40px',
                height: '40px',
                backgroundColor: `rgb(${255 - intensity}, ${255 - intensity}, 255)`
              }}
              title={value}
            />
          );
        })}
      </div>
    </Paper>
  );
};

export default AlertsHeatmap;
