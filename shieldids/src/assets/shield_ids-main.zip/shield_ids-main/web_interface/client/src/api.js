// src/api.js

// Use the API URL from environment variable or default to localhost:5050
export const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5050";

// Socket.IO configuration
export const SOCKET_OPTIONS = {
  transports: ['websocket', 'polling'], // Try WebSocket first, fallback to polling
  reconnectionAttempts: 5,
  reconnectionDelay: 1000,
  timeout: 10000
};

export function getSocketUrl() {
  return API_URL;
}

export async function getAnomalyScores() {
  const response = await fetch(`${API_URL}/api/anomalyScores`);
  if (!response.ok) {
    throw new Error("Failed to fetch anomaly scores");
  }
  return await response.json();
}
  
export async function getAlerts() {
  const response = await fetch(`${API_URL}/api/alerts`);
  if (!response.ok) {
    throw new Error("Failed to fetch alerts");
  }
  return await response.json();
}
  
export async function getTrafficVolume() {
  const response = await fetch(`${API_URL}/api/trafficVolume`);
  if (!response.ok) {
    throw new Error("Failed to fetch traffic volume");
  }
  return await response.json();
}
  
export async function getAlertDistribution() {
  const response = await fetch(`${API_URL}/api/alertDistribution`);
  if (!response.ok) {
    throw new Error("Failed to fetch alert distribution");
  }
  return await response.json();
}
  
export async function getStats() {
  const response = await fetch(`${API_URL}/api/stats`);
  if (!response.ok) {
    throw new Error("Failed to fetch stats");
  }
  return await response.json();
}
  
export async function getAlertHeatmap() {
  const response = await fetch(`${API_URL}/api/alertHeatmap`);
  if (!response.ok) {
    throw new Error("Failed to fetch alert heatmap");
  }
  return await response.json();
}
  
export async function getCorrelationData() {
  const response = await fetch(`${API_URL}/api/correlation`);
  if (!response.ok) {
    throw new Error("Failed to fetch correlation data");
  }
  return await response.json();
}
  