import React, { useMemo, useState, useEffect, useRef } from 'react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  ReferenceLine,
  Label,
  Area,
  ComposedChart
} from 'recharts';
import { Paper, Typography, Box, CircularProgress, Chip } from '@mui/material';
import { io } from 'socket.io-client';
import { API_URL, SOCKET_OPTIONS } from '../api';
import { debounce } from '../utils/performance';

// Constants for threat level thresholds
const CRITICAL_THRESHOLD = 0.7;
const WARNING_THRESHOLD = 0.4;

// Custom tooltip component for better visual presentation
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const anomalyScore = payload[0].value;
    
    // Determine threat level from score
    let threatLevel = 'Normal';
    let color = '#66bb6a'; // success/green
    
    if (anomalyScore >= CRITICAL_THRESHOLD) {
      threatLevel = 'Critical';
      color = '#f44336'; // error/red
    } else if (anomalyScore >= WARNING_THRESHOLD) {
      threatLevel = 'Elevated';
      color = '#ff9800'; // warning/orange
    }
    
    return (
      <Paper sx={{ p: 1, bgcolor: 'background.paper', border: 1, borderColor: 'divider' }}>
        <Typography variant="body2" color="text.primary">
          <strong>Time:</strong> {label}
        </Typography>
        <Typography variant="body2" sx={{ color }}>
          <strong>Anomaly Score:</strong> {anomalyScore.toFixed(3)}
        </Typography>
        <Typography variant="body2" sx={{ color, fontWeight: 'bold' }}>
          Threat Level: {threatLevel}
        </Typography>
      </Paper>
    );
  }
  return null;
};

// The component can be used in two ways:
// 1. With data provided as a prop from a parent component
// 2. As a standalone component that fetches its own data
const AnomalyHistoryChart = ({ data: propData, standalone = false }) => {
  const [localData, setLocalData] = useState([]);
  const [loading, setLoading] = useState(standalone);
  const [error, setError] = useState(null);
  const [connected, setConnected] = useState(false);
  const socketRef = useRef(null);
  
  // Use propData if provided, otherwise use localData
  const data = propData || localData;
  
  useEffect(() => {
    // Only fetch data and set up socket if in standalone mode
    if (standalone) {
      // Initial fetch
      const fetchAnomalyScores = async () => {
        try {
          setLoading(true);
          const response = await fetch(`${API_URL}/api/anomalyScores`);
          if (!response.ok) throw new Error('Failed to fetch anomaly scores');
          const data = await response.json();
          setLocalData(data);
          setError(null);
        } catch (error) {
          console.error("Error fetching anomaly scores:", error);
          setError("Failed to load anomaly history");
        } finally {
          setLoading(false);
        }
      };
      
      fetchAnomalyScores();
      
      // Connect to Socket.IO for real-time updates
      socketRef.current = io(API_URL, SOCKET_OPTIONS);
      
      socketRef.current.on('connect', () => {
        console.log('AnomalyHistory: Socket.IO connected successfully');
        setConnected(true);
        setError(null);
      });
      
      socketRef.current.on('connect_error', (error) => {
        console.error('AnomalyHistory: Socket.IO connection error:', error);
        setConnected(false);
        setError("Connection error. Real-time updates paused.");
      });
      
      // Debounced function to handle real-time updates
      const debouncedUpdate = debounce((newData) => {
        if (Array.isArray(newData) && newData.length > 0) {
          setLocalData(prevData => {
            // Limit to 50 data points to prevent performance issues
            const combinedData = [...newData, ...prevData].slice(0, 50);
            return combinedData;
          });
        }
      }, 500);
      
      // Listen for anomaly score updates
      socketRef.current.on('update', debouncedUpdate);
      
      // Cleanup on unmount
      return () => {
        if (socketRef.current) {
          socketRef.current.off('update', debouncedUpdate);
          socketRef.current.disconnect();
        }
      };
    }
  }, [standalone]);

  // Memoize gradient definitions to prevent re-renders
  const gradientDefs = useMemo(() => (
    <defs>
      {/* Gradient for the area under the line */}
      <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
        <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
        <stop offset="95%" stopColor="#8884d8" stopOpacity={0.1}/>
      </linearGradient>
      
      {/* Gradient for critical threshold */}
      <linearGradient id="criticalZone" x1="0" y1="0" x2="0" y2="1">
        <stop offset="5%" stopColor="#f44336" stopOpacity={0.2}/>
        <stop offset="95%" stopColor="#f44336" stopOpacity={0.05}/>
      </linearGradient>
      
      {/* Gradient for warning threshold */}
      <linearGradient id="warningZone" x1="0" y1="0" x2="0" y2="1">
        <stop offset="5%" stopColor="#ff9800" stopOpacity={0.2}/>
        <stop offset="95%" stopColor="#ff9800" stopOpacity={0.05}/>
      </linearGradient>
    </defs>
  ), []);

  // Format tick on Y-axis
  const formatYAxis = (value) => {
    if (value === 0) return '0';
    if (value === 1) return '1.0';
    return value.toFixed(1);
  };

  if (standalone && loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
        <Typography variant="subtitle1">Anomaly Score Trend</Typography>
        {standalone && (
          <Box>
            {connected ? (
              <Chip label="Connected" color="success" size="small" />
            ) : (
              <Chip label="Disconnected" color="error" size="small" />
            )}
          </Box>
        )}
      </Box>
      
      {standalone && error && (
        <Typography color="error" variant="body2" sx={{ mb: 2 }}>
          {error}
        </Typography>
      )}
      
      <ResponsiveContainer width="100%" height={300}>
        <ComposedChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
          {gradientDefs}
          
          {/* Background grid */}
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          
          {/* X-axis configuration */}
          <XAxis 
            dataKey="time" 
            tick={{ fill: '#90caf9' }}
            tickFormatter={(value) => value.split(':').slice(0, 2).join(':')}
          />
          
          {/* Y-axis configuration */}
          <YAxis 
            domain={[0, 1]} 
            tickFormatter={formatYAxis}
            tick={{ fill: '#90caf9' }}
          >
            <Label 
              value="Anomaly Score" 
              angle={-90} 
              position="insideLeft" 
              style={{ textAnchor: 'middle', fill: '#90caf9' }} 
            />
          </YAxis>
          
          {/* Custom tooltip */}
          <Tooltip content={<CustomTooltip />} />
          
          {/* Threshold reference lines */}
          <ReferenceLine 
            y={CRITICAL_THRESHOLD} 
            stroke="#f44336" 
            strokeDasharray="3 3"
            strokeWidth={2}
          >
            <Label 
              value="Critical" 
              position="right" 
              style={{ textAnchor: 'start', fill: '#f44336' }} 
            />
          </ReferenceLine>
          
          <ReferenceLine 
            y={WARNING_THRESHOLD} 
            stroke="#ff9800" 
            strokeDasharray="3 3"
            strokeWidth={2}
          >
            <Label 
              value="Warning" 
              position="right" 
              style={{ textAnchor: 'start', fill: '#ff9800' }} 
            />
          </ReferenceLine>
          
          {/* Fill areas for different threat zones */}
          <Area 
            type="monotone" 
            dataKey="score" 
            stroke="none"
            fill="url(#colorScore)" 
            fillOpacity={0.3}
            activeDot={false}
            isAnimationActive={false}
          />
          
          {/* Main score line */}
          <Line 
            type="monotone" 
            dataKey="score" 
            stroke="#8884d8" 
            strokeWidth={2}
            dot={{ stroke: '#8884d8', strokeWidth: 2, r: 3 }}
            activeDot={{ stroke: '#8884d8', strokeWidth: 3, r: 6 }}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1, gap: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Box 
            sx={{ 
              width: 12, 
              height: 12, 
              bgcolor: 'success.main', 
              borderRadius: '50%', 
              mr: 1 
            }} 
          />
          <Typography variant="caption">Normal (0.0-0.4)</Typography>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Box 
            sx={{ 
              width: 12, 
              height: 12, 
              bgcolor: 'warning.main', 
              borderRadius: '50%', 
              mr: 1 
            }} 
          />
          <Typography variant="caption">Elevated (0.4-0.7)</Typography>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Box 
            sx={{ 
              width: 12, 
              height: 12, 
              bgcolor: 'error.main', 
              borderRadius: '50%', 
              mr: 1 
            }} 
          />
          <Typography variant="caption">Critical (0.7-1.0)</Typography>
        </Box>
      </Box>
    </>
  );
};

export default React.memo(AnomalyHistoryChart);
