// web_interface/client/src/components/TrafficVolumeChart.js
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Paper, Typography, Box, CircularProgress } from '@mui/material';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { io } from 'socket.io-client';

// Constants for performance optimization
const MAX_DATA_POINTS = 20;
const DEBOUNCE_TIME = 300;

const TrafficVolumeChart = () => {
  const [trafficData, setTrafficData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const socketRef = useRef(null);
  const updateTimeoutRef = useRef(null);

  // Format y-axis bytes to human-readable format
  const formatBytes = (bytes) => {
    if (bytes === 0 || bytes === undefined) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${units[i]}`;
  };

  // Custom tooltip formatter - memoized to prevent re-renders
  const CustomTooltip = useMemo(() => {
    return ({ active, payload, label }) => {
      if (active && payload && payload.length) {
        return (
          <Paper sx={{ p: 1, bgcolor: 'background.paper', border: 1, borderColor: 'divider' }}>
            <Typography variant="body2" color="text.primary">
              Time: {label}
            </Typography>
            <Typography variant="body2" color="primary">
              Traffic: {formatBytes(payload[0].value)}/s
            </Typography>
          </Paper>
        );
      }
      return null;
    };
  }, []);

  // Handle real-time data updates with debouncing to prevent too frequent updates
  const handleTrafficUpdate = (newData) => {
    if (updateTimeoutRef.current) {
      clearTimeout(updateTimeoutRef.current);
    }

    updateTimeoutRef.current = setTimeout(() => {
      if (newData && newData.length > 0) {
        setTrafficData(prev => {
          // Keep only the latest MAX_DATA_POINTS data points for performance
          const combinedData = [...prev, ...newData];
          return combinedData.slice(-MAX_DATA_POINTS);
        });
      }
    }, DEBOUNCE_TIME);
  };

  useEffect(() => {
    // Initial data fetch
    const fetchTraffic = async () => {
      setLoading(true);
      try {
        const response = await fetch("http://localhost:5050/api/trafficVolume");
        if (!response.ok) throw new Error("Failed to fetch traffic data");
        const data = await response.json();
        setTrafficData(data);
        setError(null);
      } catch (error) {
        console.error("Error fetching traffic volume:", error);
        setError("Failed to load traffic data. Please check your network connection.");
      } finally {
        setLoading(false);
      }
    };
    
    fetchTraffic();

    // Set up Socket.IO for real-time updates with optimized configuration
    socketRef.current = io("http://localhost:5050", {
      transports: ['websocket'], // Use websocket only for better performance
      reconnectionAttempts: 5,
      reconnectionDelay: 1000
    });
    
    socketRef.current.on("trafficUpdate", handleTrafficUpdate);
    
    socketRef.current.on("connect_error", (err) => {
      console.error("Socket connection error:", err);
      setError("Connection error. Real-time updates paused.");
    });
    
    socketRef.current.on("reconnect", () => {
      setError(null);
      console.log("Reconnected to server");
    });

    return () => {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
      if (socketRef.current) {
        socketRef.current.off("trafficUpdate", handleTrafficUpdate);
        socketRef.current.disconnect();
      }
    };
  }, []);

  // Memoize chart data to prevent unnecessary re-rendering
  const chartData = useMemo(() => trafficData, [trafficData]);

  return (
    <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
      <Typography variant="h6" gutterBottom>
        Network Traffic Volume
      </Typography>
      
      {error && (
        <Typography color="error" variant="body2" sx={{ mb: 2 }}>
          {error}
        </Typography>
      )}
      
      <Box sx={{ width: '100%', height: 300, position: 'relative' }}>
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
            <CircularProgress />
          </Box>
        ) : chartData.length === 0 ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
            <Typography color="text.secondary">No traffic data available</Typography>
          </Box>
        ) : (
          <ResponsiveContainer>
            <LineChart 
              data={chartData}
              margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="time" 
                stroke="#90caf9"
                tick={{ fill: '#90caf9' }}
                tickFormatter={(value) => value.split(':').slice(0, 2).join(':')}
              />
              <YAxis 
                tickFormatter={formatBytes}
                stroke="#90caf9"
                tick={{ fill: '#90caf9' }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="bytesPerSec" 
                name="Traffic Volume" 
                stroke="#8884d8" 
                fill="url(#colorBytes)"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 8 }}
                isAnimationActive={false}
              />
              <defs>
                <linearGradient id="colorBytes" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
                </linearGradient>
              </defs>
            </LineChart>
          </ResponsiveContainer>
        )}
      </Box>
    </Paper>
  );
};

export default React.memo(TrafficVolumeChart);