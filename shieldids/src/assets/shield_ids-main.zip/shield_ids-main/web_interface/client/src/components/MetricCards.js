import React, { useState, useEffect } from 'react';
import { Box, Grid, Paper, Typography, Divider } from '@mui/material';
import { io } from 'socket.io-client';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import SecurityIcon from '@mui/icons-material/Security';
import ShieldIcon from '@mui/icons-material/Shield';
import { API_URL, SOCKET_OPTIONS, getStats } from '../api';

const MetricCards = () => {
  const [totalAlerts, setTotalAlerts] = useState(0);
  const [activeThreats, setActiveThreats] = useState(0);
  const [recentAttacks, setRecentAttacks] = useState(0);
  const [avgAnomalyScore, setAvgAnomalyScore] = useState(0);

  useEffect(() => {
    // Initial data fetch
    fetchData();

    // Set up Socket.IO connection for real-time updates
    const socket = io(API_URL, SOCKET_OPTIONS);
    
    // Log connection events
    socket.on('connect', () => {
      console.log('MetricCards: Socket.IO connected');
    });
    
    socket.on('connect_error', (error) => {
      console.error('MetricCards: Socket.IO connection error:', error);
    });
    
    socket.on("alertUpdate", (alert) => {
      // When we receive a new alert, increment our counts
      if (Array.isArray(alert)) {
        // If we get an array of alerts (initial load)
        setTotalAlerts(alert.length);
        
        // Count recent attacks (last 5 minutes)
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
        const recentCount = alert.filter(a => {
          const alertTime = a.timestamp ? new Date(a.timestamp) : null;
          return alertTime && alertTime > fiveMinutesAgo;
        }).length;
        setRecentAttacks(recentCount);
        
        // Estimate active threats based on unique source IPs in recent alerts
        const uniqueThreats = new Set(
          alert.filter(a => a.src_ip).map(a => a.src_ip)
        );
        setActiveThreats(uniqueThreats.size);
      } else {
        // If we get a single alert (real-time update)
        setTotalAlerts(prev => prev + 1);
        setRecentAttacks(prev => prev + 1);
        
        // We can't accurately update active threats with just one alert
        // so we'll trigger a full refresh
        fetchData();
      }
    });
    
    // Also listen for anomaly score updates
    socket.on("update", (data) => {
      if (Array.isArray(data) && data.length > 0) {
        // Calculate average of recent scores
        const sum = data.reduce((acc, item) => acc + (item.score || 0), 0);
        const avg = sum / data.length;
        setAvgAnomalyScore(prev => (prev * 0.7) + (avg * 0.3)); // Smooth the average
      }
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const fetchData = async () => {
    try {
      // Fetch stats from the API
      const stats = await getStats();
      setTotalAlerts(stats.totalAlerts || 0);
      setAvgAnomalyScore(stats.avgAnomalyScore || 0);
      
      // Fetch alerts to calculate active threats
      const response = await fetch(`${API_URL}/api/alerts`);
      const alerts = await response.json();
      
      // Count recent attacks (last 5 minutes)
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      const recentCount = alerts.filter(a => {
        const alertTime = a.timestamp ? new Date(a.timestamp) : null;
        return alertTime && alertTime > fiveMinutesAgo;
      }).length;
      setRecentAttacks(recentCount);
      
      // Estimate active threats based on unique source IPs in recent alerts
      const uniqueThreats = new Set(
        alerts.filter(a => a.src_ip).map(a => a.src_ip)
      );
      setActiveThreats(uniqueThreats.size);
    } catch (error) {
      console.error("Error fetching metric data:", error);
    }
  };

  // Determine color based on threat level
  const getMetricColor = (value, threshold1, threshold2) => {
    if (value >= threshold2) return 'error.main';
    if (value >= threshold1) return 'warning.main';
    return 'success.main';
  };

  // Format the card metric based on the metric type
  const formatMetric = (value, type) => {
    if (type === 'score') {
      // Format as a score out of 1.0
      return value.toFixed(2);
    }
    // Format as a whole number
    return value.toLocaleString();
  };

  return (
    <Grid container spacing={2} sx={{ mb: 3 }}>
      <Grid item xs={12} sm={6} md={3}>
        <Paper elevation={1} sx={{ p: 2, display: 'flex', flexDirection: 'column', height: '100%' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <WarningAmberIcon sx={{ mr: 1, color: getMetricColor(totalAlerts, 5, 20) }} />
            <Typography variant="h6">Total Alerts</Typography>
          </Box>
          <Divider sx={{ mb: 2 }} />
          <Typography variant="h3" sx={{ fontWeight: 'bold', color: getMetricColor(totalAlerts, 5, 20) }}>
            {formatMetric(totalAlerts)}
          </Typography>
        </Paper>
      </Grid>
      
      <Grid item xs={12} sm={6} md={3}>
        <Paper elevation={1} sx={{ p: 2, display: 'flex', flexDirection: 'column', height: '100%' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <ShieldIcon sx={{ mr: 1, color: getMetricColor(recentAttacks, 3, 10) }} />
            <Typography variant="h6">Recent Attacks</Typography>
          </Box>
          <Divider sx={{ mb: 2 }} />
          <Typography variant="h3" sx={{ fontWeight: 'bold', color: getMetricColor(recentAttacks, 3, 10) }}>
            {formatMetric(recentAttacks)}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            In the last 5 minutes
          </Typography>
        </Paper>
      </Grid>
      
      <Grid item xs={12} sm={6} md={3}>
        <Paper elevation={1} sx={{ p: 2, display: 'flex', flexDirection: 'column', height: '100%' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <SecurityIcon sx={{ mr: 1, color: getMetricColor(activeThreats, 2, 5) }} />
            <Typography variant="h6">Active Threats</Typography>
          </Box>
          <Divider sx={{ mb: 2 }} />
          <Typography variant="h3" sx={{ fontWeight: 'bold', color: getMetricColor(activeThreats, 2, 5) }}>
            {formatMetric(activeThreats)}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Unique threat sources
          </Typography>
        </Paper>
      </Grid>
      
      <Grid item xs={12} sm={6} md={3}>
        <Paper elevation={1} sx={{ p: 2, display: 'flex', flexDirection: 'column', height: '100%' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <SecurityIcon sx={{ mr: 1, color: getMetricColor(avgAnomalyScore, 0.4, 0.7) }} />
            <Typography variant="h6">Anomaly Score</Typography>
          </Box>
          <Divider sx={{ mb: 2 }} />
          <Typography variant="h3" sx={{ fontWeight: 'bold', color: getMetricColor(avgAnomalyScore, 0.4, 0.7) }}>
            {formatMetric(avgAnomalyScore, 'score')}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Average recent score
          </Typography>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default MetricCards; 