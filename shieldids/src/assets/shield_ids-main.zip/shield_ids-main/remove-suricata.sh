#!/bin/bash

# Script to remove Suricata from the repository and create a clean commit

echo "=== Removing Suricata from Git repository ==="

# First, remove Suricata completely from Git tracking
echo "Removing Suricata from Git tracking..."
git rm -r --cached suricata-7.0.9/

# Create a directory to store Suricata docs if you want to preserve them
echo "Creating suricata-docs directory to preserve important documentation..."
mkdir -p suricata-docs

# Copy only essential documentation (no binaries)
cp suricata-7.0.9/README.md suricata-docs/ 2>/dev/null || echo "No README.md found"
cp suricata-7.0.9/INSTALL.md suricata-docs/ 2>/dev/null || echo "No INSTALL.md found"
cp -r suricata-7.0.9/doc/getting-started suricata-docs/ 2>/dev/null || echo "No getting-started docs found"

# Add the docs back to Git
git add suricata-docs/

# Update the .gitignore to exclude the entire Suricata directory
echo "Updating .gitignore to permanently exclude Suricata..."
echo "# Exclude entire Suricata source directory" >> .gitignore
echo "suricata-7.0.9/" >> .gitignore

# Add .gitignore to track the changes
git add .gitignore

# Setup proper LFS tracking for the traffic features file
echo "Setting up Git LFS for important data files..."
git lfs install
git lfs track "kitsune/data/processed/traffic_features.csv"
git add .gitattributes
git add kitsune/data/processed/traffic_features.csv

echo "Creating documentation on how to build Suricata instead..."
cat > BUILD-SURICATA.md << 'EOF'
# Building Suricata

Instead of including Suricata binaries in this repository, please follow these instructions to build it from source:

## Prerequisites

```bash
# Install Suricata dependencies
sudo apt update
sudo apt install -y build-essential libpcre3-dev libpcre3 libpcap-dev libnet1-dev \
  libyaml-0-2 libyaml-dev pkg-config zlib1g zlib1g-dev libcap-ng-dev libcap-ng0 \
  libmagic-dev libnss3-dev libgeoip-dev liblua5.1-0-dev libhtp-dev libjansson-dev \
  libjansson4 libpython2.7-dev rustc cargo
```

## Download and Build

```bash
# Download Suricata source (version 7.0.9)
wget https://www.openinfosecfoundation.org/download/suricata-7.0.9.tar.gz
tar -xvzf suricata-7.0.9.tar.gz
cd suricata-7.0.9

# Configure and build Suricata
./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var \
  --enable-nfqueue --enable-lua --enable-geoip --enable-rust
make -j $(nproc)

# Install Suricata (optional, requires root)
sudo make install
sudo make install-conf

# Setup Suricata rules (optional)
sudo suricata-update
```

## Verification

To verify Suricata is properly installed:

```bash
suricata --version
```

You should see output showing Suricata version 7.0.9.
EOF

# Add the build instructions to git
git add BUILD-SURICATA.md

echo "===== COMPLETE ====="
echo ""
echo "Now commit and push your changes with:"
echo "git commit -m \"Remove Suricata source code and binaries\""
echo "git push -u origin main" 