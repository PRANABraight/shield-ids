# SHIELD IDS - Real-Time Network Intrusion Detection System

SHIELD IDS is a real-time web-based Intrusion Detection System that integrates Suricata and Kitsune ML-based anomaly detection to provide comprehensive network security monitoring.

![SHIELD IDS Dashboard](docs/dashboard.png)

## Features

- **Real-time Attack Detection**: Monitors network traffic using Suricata's signature-based detection
- **Anomaly Detection**: Machine learning-based detection of unusual network behavior using Kitsune
- **Interactive Dashboard**: Web interface with real-time updates via WebSocket
- **Alerts Visualization**: Comprehensive view of security alerts with severity indicators
- **Traffic Analysis**: Network traffic volume monitoring and correlation with anomaly scores
- **Customizable Deployment**: Supports both Docker and bare-metal deployments

## Architecture

SHIELD IDS consists of the following components:

- **Suricata**: Industry-standard, open-source network threat detection engine
- **Kitsune**: Plug-and-play ML-based NIDS for anomaly detection (optional)
- **Backend Server**: Node.js application for log processing and real-time data distribution
- **Redis**: In-memory database for storing and retrieving security events
- **Web Interface**: React-based UI for visualization and monitoring

## Prerequisites

- Linux-based operating system (Ubuntu 20.04+ recommended)
- Node.js 16+ and npm
- Redis
- For Suricata: build tools and required libraries

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/shield_ids.git
cd shield_ids
```

### 2. Building Suricata (from source)

Instead of including Suricata binaries in this repository, you should build it from source:

```bash
# Install Suricata dependencies
sudo apt update
sudo apt install -y build-essential libpcre3-dev libpcre3 libpcap-dev libnet1-dev \
  libyaml-0-2 libyaml-dev pkg-config zlib1g zlib1g-dev libcap-ng-dev libcap-ng0 \
  libmagic-dev libnss3-dev libgeoip-dev liblua5.1-0-dev libhtp-dev libjansson-dev \
  libjansson4 libpython2.7-dev rustc cargo

# Download Suricata source (version 7.0.9)
wget https://www.openinfosecfoundation.org/download/suricata-7.0.9.tar.gz
tar -xvzf suricata-7.0.9.tar.gz
cd suricata-7.0.9

# Configure and build Suricata
./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var \
  --enable-nfqueue --enable-lua --enable-geoip --enable-rust
make -j $(nproc)

# Install Suricata (optional, requires root)
sudo make install
sudo make install-conf

# Setup Suricata rules (optional)
sudo suricata-update

# Return to the project directory
cd ..
```

### 3. Install Backend Dependencies

```bash
cd web_interface/server
npm install
```

### 4. Install Frontend Dependencies

```bash
cd ../client
npm install
```

### 5. Configure the Application

Create a `.env` file in the server directory:

```bash
cd ../server
cat > .env << EOF
PORT=5050
REDIS_URL=redis://localhost:6379
SURICATA_EVE_LOG=/var/log/suricata/eve.json
EOF
```

## Running the Application

### 1. Start Redis

```bash
sudo systemctl start redis
```

### 2. Start the Backend Server

```bash
cd web_interface/server
node server.js
```

### 3. Start the Frontend Application (Development Mode)

```bash
cd ../client
npm start
```

The application will be available at `http://localhost:3000`

## Docker Deployment

For easier deployment, you can use Docker:

```bash
# Build and start all services
docker-compose up -d

# Or for production with actual Suricata logs
docker-compose -f docker-compose.prod.yml up -d
```

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed deployment instructions.

## Testing with Simulated Attacks

You can test the system with simulated attacks:

```bash
cd web_interface/server/scripts
node attack-simulation.js --interval 3000
```

## Development

### Backend Development

```bash
cd web_interface/server
npm install
npm run dev  # Starts with nodemon for auto-reload
```

### Frontend Development

```bash
cd web_interface/client
npm install
npm start  # Starts React development server
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Suricata: https://suricata.io/
- Kitsune: https://github.com/ymirsky/KitNET-py
- React: https://reactjs.org/
- Socket.IO: https://socket.io/ 