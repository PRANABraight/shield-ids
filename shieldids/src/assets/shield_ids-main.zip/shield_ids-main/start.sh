#!/bin/bash

# SHIELD IDS Startup Script
# This script launches all components needed for the SHIELD IDS system

# Color definitions
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# Display banner
echo -e "${BOLD}${GREEN}"
echo "  _____ _    _ _____ ______ _      _____    _____ _____   _____ "
echo " / ____| |  | |_   _|  ____| |    |  __ \  |_   _|  __ \ / ____|"
echo "| (___ | |__| | | | | |__  | |    | |  | |   | | | |  | | (___  "
echo " \___ \|  __  | | | |  __| | |    | |  | |   | | | |  | |\___ \ "
echo " ____) | |  | |_| |_| |____| |____| |__| |  _| |_| |__| |____) |"
echo "|_____/|_|  |_|_____|______|______|_____/  |_____|_____/|_____/ "
echo -e "${NC}"
echo -e "${BOLD}Real-Time Network Intrusion Detection System${NC}"
echo ""

# Default values
SURICATA_EVE_LOG="/var/log/suricata/eve.json"
GENERATE_TEST_LOGS=false
SERVER_PORT=5050
CLIENT_PORT=3000
SERVER_DIR="web_interface/server"
CLIENT_DIR="web_interface/client"

# Parse command line arguments
while (( "$#" )); do
  case "$1" in
    --eve-log)
      SURICATA_EVE_LOG="$2"
      shift 2
      ;;
    --generate-logs)
      GENERATE_TEST_LOGS=true
      shift
      ;;
    --server-port)
      SERVER_PORT="$2"
      shift 2
      ;;
    --client-port)
      CLIENT_PORT="$2"
      shift 2
      ;;
    --help)
      echo "Usage: ./start.sh [options]"
      echo ""
      echo "Options:"
      echo "  --eve-log <path>      Path to Suricata eve.json log file (default: /var/log/suricata/eve.json)"
      echo "  --generate-logs       Generate test logs instead of using real Suricata logs"
      echo "  --server-port <port>  Port for the backend server (default: 5050)"
      echo "  --client-port <port>  Port for the React development server (default: 3000)"
      echo "  --help                Display this help message"
      exit 0
      ;;
    *)
      echo "Error: Unsupported option $1"
      echo "Run './start.sh --help' for usage information"
      exit 1
      ;;
  esac
done

# Function to check if a command exists
command_exists() {
  command -v "$1" &> /dev/null
}

# Kill existing processes
kill_existing_processes() {
  echo -e "${BOLD}Checking for existing processes...${NC}"
  
  # Kill any running server instance
  if lsof -i :$SERVER_PORT -t &>/dev/null; then
    echo -e "${YELLOW}⚠ Found existing server on port $SERVER_PORT. Stopping...${NC}"
    kill $(lsof -i :$SERVER_PORT -t) &>/dev/null
    sleep 1
  fi
  
  # Kill any running client instance
  if lsof -i :$CLIENT_PORT -t &>/dev/null; then
    echo -e "${YELLOW}⚠ Found existing client on port $CLIENT_PORT. Stopping...${NC}"
    kill $(lsof -i :$CLIENT_PORT -t) &>/dev/null
    sleep 1
  fi
  
  # Kill existing log generator
  pkill -f "node.*eve-log-generator" &>/dev/null
  if [ $? -eq 0 ]; then
    echo -e "${YELLOW}⚠ Stopped existing log generator${NC}"
  fi
  
  # Remove PID files
  rm -f .server.pid .client.pid .log_generator.pid &>/dev/null
}

# Check for required dependencies
echo -e "${BOLD}Checking dependencies...${NC}"
MISSING_DEPS=false

if ! command_exists node; then
  echo -e "${RED}✗ Node.js is not installed${NC}"
  MISSING_DEPS=true
else
  NODE_VERSION=$(node -v)
  echo -e "${GREEN}✓ Node.js ${NODE_VERSION} is installed${NC}"
fi

if ! command_exists npm; then
  echo -e "${RED}✗ npm is not installed${NC}"
  MISSING_DEPS=true
else
  NPM_VERSION=$(npm -v)
  echo -e "${GREEN}✓ npm ${NPM_VERSION} is installed${NC}"
fi

if ! command_exists redis-cli; then
  echo -e "${YELLOW}⚠ Redis CLI not found - Redis may not be installed${NC}"
  echo -e "${YELLOW}  The application requires Redis to be running${NC}"
else
  echo -e "${GREEN}✓ Redis is installed${NC}"
fi

if [[ "$MISSING_DEPS" == true ]]; then
  echo -e "${RED}Error: Missing required dependencies${NC}"
  exit 1
fi

# Check if Redis is running
echo -e "${BOLD}Checking Redis server...${NC}"
if ! redis-cli ping &>/dev/null; then
  echo -e "${YELLOW}⚠ Redis server is not running. Attempting to start...${NC}"
  if command_exists systemctl; then
    sudo systemctl start redis &>/dev/null
    if redis-cli ping &>/dev/null; then
      echo -e "${GREEN}✓ Redis server started successfully${NC}"
    else
      echo -e "${YELLOW}⚠ Could not start Redis server. You may need to start it manually.${NC}"
      echo -e "${YELLOW}  The application will continue, but may not function correctly.${NC}"
    fi
  else
    echo -e "${YELLOW}⚠ Could not automatically start Redis. Please start it manually.${NC}"
    echo -e "${YELLOW}  The application will continue, but may not function correctly.${NC}"
  fi
else
  echo -e "${GREEN}✓ Redis server is running${NC}"
fi

# First kill existing processes
kill_existing_processes

# Check if directories exist
if [ ! -d "$SERVER_DIR" ]; then
  echo -e "${RED}Error: Server directory not found: $SERVER_DIR${NC}"
  exit 1
fi

if [ ! -d "$CLIENT_DIR" ]; then
  echo -e "${RED}Error: Client directory not found: $CLIENT_DIR${NC}"
  exit 1
fi

# Install dependencies if node_modules doesn't exist
echo -e "${BOLD}Checking for npm dependencies...${NC}"
if [ ! -d "$SERVER_DIR/node_modules" ]; then
  echo -e "${YELLOW}⚠ Server dependencies not found. Installing...${NC}"
  (cd "$SERVER_DIR" && npm install)
else
  echo -e "${GREEN}✓ Server dependencies are installed${NC}"
fi

if [ ! -d "$CLIENT_DIR/node_modules" ]; then
  echo -e "${YELLOW}⚠ Client dependencies not found. Installing...${NC}"
  (cd "$CLIENT_DIR" && npm install)
else
  echo -e "${GREEN}✓ Client dependencies are installed${NC}"
fi

# Generate test logs if requested
if [[ "$GENERATE_TEST_LOGS" == true ]]; then
  echo -e "${BOLD}Generating test logs...${NC}"
  TEST_LOG_PATH="$PWD/test-eve.json"
  
  # Start the log generator in the background
  node "$SERVER_DIR/scripts/eve-log-generator.js" "$TEST_LOG_PATH" 1000 &
  LOG_GEN_PID=$!
  echo $LOG_GEN_PID > .log_generator.pid
  echo -e "${GREEN}✓ Started log generator (PID: $LOG_GEN_PID)${NC}"
  echo -e "${GREEN}✓ Writing logs to: $TEST_LOG_PATH${NC}"
  
  # Set the EVE log path to our test file
  SURICATA_EVE_LOG="$TEST_LOG_PATH"
  
  # Wait a moment for some initial logs to be generated
  sleep 2
fi

# Absolute path to the eve log
if [[ "$SURICATA_EVE_LOG" != /* ]]; then
  SURICATA_EVE_LOG="$PWD/$SURICATA_EVE_LOG"
fi

# Define the server URL for the client to connect to
SERVER_URL="http://localhost:$SERVER_PORT"

# Create a temporary .env file for the React client
echo "REACT_APP_API_URL=$SERVER_URL" > "$CLIENT_DIR/.env"
echo -e "${GREEN}✓ Set API URL to $SERVER_URL${NC}"

# Start the server with proper CORS configuration
echo -e "${BOLD}Starting server...${NC}"
(
  cd "$SERVER_DIR" && \
  SURICATA_EVE_LOG="$SURICATA_EVE_LOG" \
  PORT="$SERVER_PORT" \
  CORS_ORIGIN="http://localhost:$CLIENT_PORT" \
  NODE_ENV=development \
  node server.js &
) 
SERVER_PID=$!
echo $SERVER_PID > .server.pid
echo -e "${GREEN}✓ Started server (PID: $SERVER_PID)${NC}"
echo -e "${GREEN}✓ Server is running at $SERVER_URL${NC}"
echo -e "${GREEN}✓ Using Suricata logs from: $SURICATA_EVE_LOG${NC}"

# Wait a bit for the server to start up
sleep 5

# Start the client with explicit API URL
echo -e "${BOLD}Starting client...${NC}"
(
  cd "$CLIENT_DIR" && \
  PORT="$CLIENT_PORT" \
  BROWSER="none" \
  npm start &
)
CLIENT_PID=$!
echo $CLIENT_PID > .client.pid
echo -e "${GREEN}✓ Started client (PID: $CLIENT_PID)${NC}"
echo -e "${GREEN}✓ Client is running at http://localhost:$CLIENT_PORT${NC}"

# Trap SIGINT to handle clean shutdown
trap cleanup INT

function cleanup() {
  echo -e "\n${BOLD}Shutting down SHIELD IDS...${NC}"
  
  # Kill the client
  if [ -f ".client.pid" ]; then
    CLIENT_PID=$(cat .client.pid)
    if ps -p "$CLIENT_PID" > /dev/null; then
      kill "$CLIENT_PID" 2>/dev/null
      echo -e "${GREEN}✓ Stopped client${NC}"
    fi
    rm .client.pid
  fi
  
  # Kill the server
  if [ -f ".server.pid" ]; then
    SERVER_PID=$(cat .server.pid)
    if ps -p "$SERVER_PID" > /dev/null; then
      kill "$SERVER_PID" 2>/dev/null
      echo -e "${GREEN}✓ Stopped server${NC}"
    fi
    rm .server.pid
  fi
  
  # Kill the log generator if it's running
  if [ -f ".log_generator.pid" ]; then
    LOG_GEN_PID=$(cat .log_generator.pid)
    if ps -p "$LOG_GEN_PID" > /dev/null; then
      kill "$LOG_GEN_PID" 2>/dev/null
      echo -e "${GREEN}✓ Stopped log generator${NC}"
    fi
    rm .log_generator.pid
  fi
  
  # Remove temporary files
  rm -f "$CLIENT_DIR/.env"
  
  echo -e "${GREEN}${BOLD}SHIELD IDS has been shut down${NC}"
  exit 0
}

# Display instructions
echo -e "\n${BOLD}SHIELD IDS is now running!${NC}"
echo -e "Access the dashboard at ${BOLD}http://localhost:$CLIENT_PORT${NC}"
echo -e "API server running at ${BOLD}$SERVER_URL${NC}"
echo -e "\nPress ${BOLD}Ctrl+C${NC} to stop all components\n"

# Verify data flow
echo -e "${BOLD}Verifying data flow...${NC}"
sleep 5
CURL_RESULT=$(curl -s $SERVER_URL/api/anomalyScores)
if [[ "$CURL_RESULT" == *"score"* ]]; then
  echo -e "${GREEN}✓ Server API is responding with anomaly scores${NC}"
  
  # Try to open the browser automatically
  if command_exists xdg-open; then
    echo -e "${GREEN}✓ Opening browser...${NC}"
    xdg-open "http://localhost:$CLIENT_PORT" &>/dev/null || true
  fi
  
  echo -e "${GREEN}✓ System is ready to use${NC}"
else
  echo -e "${YELLOW}⚠ Could not verify anomaly scores from API${NC}"
  echo -e "${YELLOW}  You may need to check server logs for errors${NC}"
fi

# Wait for user to stop with Ctrl+C
wait 