#!/bin/bash

# Create a clean repository script for SHIELD IDS
# This script helps prepare the repository for GitHub by removing binary files

echo "Cleaning SHIELD IDS repository..."

# Create .gitattributes file for LFS
echo "kitsune/data/processed/traffic_features.csv filter=lfs diff=lfs merge=lfs -text" > .gitattributes

# Setup Git LFS
git lfs install
git lfs track "kitsune/data/processed/traffic_features.csv"

# Remove all LFS tracked files except for the traffic_features.csv
git rm --cached -r suricata-7.0.9/rust/target
git rm --cached -r suricata-7.0.9/src/.libs
git rm --cached suricata-7.0.9/doc/userguide/userguide.pdf
git rm --cached suricata-7.0.9/rust/src/applayertemplate/template.pcap
git rm --cached suricata-7.0.9/rust/src/dhcp/*.pcap
git rm --cached suricata-7.0.9/rust/vendor/**/*.bin
git rm --cached suricata-7.0.9/suricata-update/tests/*.tar.gz
git rm --cached suricata-7.0.9/suricata-update/tests/*.zip

# Ensure the data file is tracked correctly
git add kitsune/data/processed/traffic_features.csv
git add .gitattributes

echo "Repository cleaning complete!"
echo "Now you can add, commit and push your changes:"
echo "git add ."
echo "git commit -m \"Initial clean commit of SHIELD IDS\""
echo "git push -u origin main" 